#include <stdio.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <math.h>
#include "struct.h"
#include "logic.h"
#include <time.h>

void draw_tanks(SDL_Renderer *ren, Tank *tanks) {
    for (int i = 0; i < number_of_players; i++) {
        if (tanks[i].exists) {
            for (double i1 = -tank_pipe_span;
                 i1 < tank_pipe_span; i1 += (double) tank_pipe_span / tank_pipe_howmany_lines) {
                aalineRGBA(ren, tanks[i].x, tanks[i].y,
                           (cos(degtorad(tanks[i].angel + i1)) * tank_pipe_length + tanks[i].x),
                           (sin(degtorad(tanks[i].angel + i1)) * tank_pipe_length + tanks[i].y), 0,
                           0, 0, 255);
            }

            filledCircleRGBA(ren, tanks[i].x, tanks[i].y, tankradius - 1, tanks[i].color.r, tanks[i].color.g,
                             tanks[i].color.b, 255);
            aacircleRGBA(ren, tanks[i].x, tanks[i].y, tankradius - 1, tanks[i].color.r, tanks[i].color.g,
                         tanks[i].color.b, 255);
            aacircleRGBA(ren, tanks[i].x, tanks[i].y, tankradius, tanks[i].color.r, tanks[i].color.g, tanks[i].color.b,
                         255);

            //////////////////////////////////////////health display: for two tanks only
            for (int ii = 0; ii < tanks[i].exists; ii++) {
                int offsetx = 30 + ii * 50, offsety = i ? windowHeight + scoreBoardHeight - 30 : windowHeight +
                                                                                                 scoreBoardHeight - 70;
                filledCircleRGBA(ren, offsetx - 10, offsety, 10, tanks[i].color.r, tanks[i].color.g, tanks[i].color.b,
                                 255);
                filledCircleRGBA(ren, offsetx + 10, offsety, 10, tanks[i].color.r, tanks[i].color.g, tanks[i].color.b,
                                 255);
                filledTrigonRGBA(ren, offsetx - 20, offsety, offsetx + 20, offsety, offsetx, offsety + 13,
                                 tanks[i].color.r, tanks[i].color.g, tanks[i].color.b, 255);
                filledTrigonRGBA(ren, offsetx - 12, offsety + 10, offsetx + 12, offsety + 10, offsetx, offsety + 20,
                                 tanks[i].color.r, tanks[i].color.g, tanks[i].color.b, 255);
            }

            switch (tanks[i].powerUP) {
                case 1:
                    thickLineRGBA(ren, tanks[i].x, tanks[i].y - (PUradius - 5), tanks[i].x, tanks[i].y + (PUradius - 5),
                                  3, 255, 255, 255,
                                  255);
                    break;
                case 2:
                    thickLineRGBA(ren, tanks[i].x, tanks[i].y - (PUradius - 5), tanks[i].x, tanks[i].y + (PUradius - 5),
                                  9, 255, 255, 255,
                                  255);
                    break;
                case 3:
                case 33:
                    for (int ii = 0; ii < 360; ii += 45) {
                        filledCircleRGBA(ren, tanks[i].x + cos(degtorad(ii)) * (PUradius - 7),
                                         tanks[i].y + sin(degtorad(ii)) * (PUradius - 7), 2, 255, 255, 255, 255);
                    }
                    break;
                case 4:
                    filledCircleRGBA(ren, tanks[i].x, tanks[i].y, 4, 255, 255, 255, 255);
                    filledCircleRGBA(ren, tanks[i].x - 8, tanks[i].y, 4, 255, 255, 255, 255);
                    filledCircleRGBA(ren, tanks[i].x + 8, tanks[i].y, 4, 255, 255, 255, 255);
                    break;
                case 5:
                    aacircleRGBA(ren, tanks[i].x, tanks[i].y, PUradius / 2, 255, 255, 255, 255);
                    break;
            }
        }
    }
}

void draw_bullets(SDL_Renderer *ren, Bullet *bullet_adress) {
    for (; bullet_adress; bullet_adress = bullet_adress->next) {
        switch (bullet_adress->type) {
            case 1:
                circleRGBA(ren, bullet_adress->x, bullet_adress->y, bullet_adress->radius, bullet_adress->color.r,
                           bullet_adress->color.g, bullet_adress->color.b, 255);
                break;

            case 7:
                if (SDL_GetTicks() - bullet_adress->birthday > mine_activation_delay &&
                    SDL_GetTicks() - bullet_adress->mineDetect < 1000 / fps)
                    continue;

            default:
                filledCircleRGBA(ren, bullet_adress->x, bullet_adress->y, bullet_adress->radius,
                                 bullet_adress->color.r,
                                 bullet_adress->color.g, bullet_adress->color.b, 255);
        }
    }
}

void draw_walls(SDL_Renderer *ren) {
    Wall *wall_scroller = walls;
    while (wall_scroller) {
        thickLineRGBA(ren, wall_scroller->x1, wall_scroller->y1, wall_scroller->x2,
                      wall_scroller->y2, wall_width, 0, 0, 0, 255);
        wall_scroller = wall_scroller->next;
    }
}

void drawScoreBoard(SDL_Renderer *ren, Tank *tanks) { ////////////////////////////// only for two tanks
    filledCircleRGBA(ren, windowWidth / 3, windowHeight + scoreBoardHeight / 2, 40, tanks[0].color.r, tanks[0].color.g,
                     tanks[0].color.b,
                     255);
    filledCircleRGBA(ren, windowWidth / 3 * 2, windowHeight + scoreBoardHeight / 2, 40, tanks[1].color.r,
                     tanks[1].color.g,
                     tanks[1].color.b, 255);
    aacircleRGBA(ren, windowWidth / 3, windowHeight + scoreBoardHeight / 2, 40, tanks[0].color.r, tanks[0].color.g,
                 tanks[0].color.b,
                 255);
    aacircleRGBA(ren, windowWidth / 3, windowHeight + scoreBoardHeight / 2, 41, tanks[0].color.r, tanks[0].color.g,
                 tanks[0].color.b,
                 255);
    aacircleRGBA(ren, windowWidth / 3 * 2, windowHeight + scoreBoardHeight / 2, 40, tanks[1].color.r, tanks[1].color.g,
                 tanks[1].color.b,
                 255);
    aacircleRGBA(ren, windowWidth / 3 * 2, windowHeight + scoreBoardHeight / 2, 41, tanks[1].color.r, tanks[1].color.g,
                 tanks[1].color.b,
                 255);

    char score0[10], score1[10];
    sprintf(score0, "%d", tanks[0].score);
    sprintf(score1, "%d", tanks[1].score);

    SDL_RenderSetScale(ren, 1.5, 1.5);
    stringRGBA(ren, (windowWidth / 3 - (int) log(tanks[0].score + 5) * 4) / 1.5,
               (windowHeight + scoreBoardHeight / 2) / 1.5, score0, 255, 255, 255, 255);
    stringRGBA(ren, (windowWidth / 3 * 2 - (int) log(tanks[1].score + 5) * 4) / 1.5,
               (windowHeight + scoreBoardHeight / 2) / 1.5, score1, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);
}

void drawPowerups(SDL_Renderer *ren) {
    for (Powerup *worm = puHead; worm; worm = worm->next) {
        filledCircleRGBA(ren, worm->x, worm->y, PUradius - 1, 51, 153, 255, 255);
        aacircleRGBA(ren, worm->x, worm->y, PUradius - 1, 51, 153, 255, 255);
        aacircleRGBA(ren, worm->x, worm->y, PUradius, 51, 153, 255, 255);
        switch (worm->type) {
            case 0:
                thickLineRGBA(ren, worm->x - (PUradius - 5), worm->y, worm->x + (PUradius - 5), worm->y, 5, 255, 255,
                              255,
                              255);
                thickLineRGBA(ren, worm->x, worm->y - (PUradius - 5), worm->x, worm->y + (PUradius - 5), 5, 255, 255,
                              255,
                              255);
                break;
            case 1:
                thickLineRGBA(ren, worm->x, worm->y - (PUradius - 5), worm->x, worm->y + (PUradius - 5), 3, 255, 255,
                              255,
                              255);
                break;
            case 2:
                thickLineRGBA(ren, worm->x, worm->y - (PUradius - 5), worm->x, worm->y + (PUradius - 5), 9, 255, 255,
                              255,
                              255);
                break;
            case 3:
                for (int i = 0; i < 360; i += 45) {
                    filledCircleRGBA(ren, worm->x + cos(degtorad(i)) * (PUradius - 7),
                                     worm->y + sin(degtorad(i)) * (PUradius - 7), 2, 255, 255, 255, 255);
                }
                break;
            case 4:
                filledCircleRGBA(ren, worm->x, worm->y, 4, 255, 255, 255, 255);
                filledCircleRGBA(ren, worm->x - 8, worm->y, 4, 255, 255, 255, 255);
                filledCircleRGBA(ren, worm->x + 8, worm->y, 4, 255, 255, 255, 255);
                break;
            case 5:
                aacircleRGBA(ren, worm->x, worm->y, PUradius / 2, 255, 255, 255, 255);
                break;
        }
    }
}

void draw_all(SDL_Renderer *ren, Tank *tanks, Bullet *first_bullet_adress) {
    draw_tanks(ren, tanks);
    draw_bullets(ren, first_bullet_adress);
    draw_walls(ren);
    drawScoreBoard(ren, tanks);
    drawPowerups(ren);
}

void drawMenu(SDL_Renderer *ren, int selected) {
    boxRGBA(ren, 0, 0, windowWidth, windowHeight + scoreBoardHeight, 100, 100, 100, 200);

    boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 2 / 3, windowWidth / 3 * 2,
            3 * (windowHeight + scoreBoardHeight) / 26 * 5 / 3, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 3, 3);
    stringRGBA(ren, (windowWidth / 3 + 115) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 2 / 3 +
                                                  3 * (windowHeight + scoreBoardHeight) / 26 * 5 / 3) / 2 / 3,
               "Resume game", 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);

    boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 2, windowWidth / 3 * 2,
            3 * (windowHeight + scoreBoardHeight) / 26 * 3, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 3, 3);
    stringRGBA(ren, (windowWidth / 3 + 60) / 3,
               (3 * (windowHeight + scoreBoardHeight) / 26 * 2 + 3 * (windowHeight + scoreBoardHeight) / 26 * 3) / 2 /
               3, "Start a new game", 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);

    boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 10 / 3, windowWidth / 3 * 2,
            3 * (windowHeight + scoreBoardHeight) / 26 * 13 / 3, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 3, 3);
    stringRGBA(ren, (windowWidth / 3 + 115) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 10 / 3 +
                                                  3 * (windowHeight + scoreBoardHeight) / 26 * 13 / 3) / 2 / 3,
               "Load a game", 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);

    boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 14 / 3, windowWidth / 3 * 2,
            3 * (windowHeight + scoreBoardHeight) / 26 * 17 / 3, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 3, 3);
    stringRGBA(ren, (windowWidth / 3 + 140) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 14 / 3 +
                                                  3 * (windowHeight + scoreBoardHeight) / 26 * 17 / 3) / 2 / 3,
               "Edit keys", 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);

    boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 6, windowWidth / 3 * 2,
            3 * (windowHeight + scoreBoardHeight) / 26 * 7, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 3, 3);
    stringRGBA(ren, (windowWidth / 3 + 50) / 3,
               (3 * (windowHeight + scoreBoardHeight) / 26 * 6 + 3 * (windowHeight + scoreBoardHeight) / 26 * 7) / 2 /
               3, "Play/Pause sound", 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);

    boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 22 / 3, windowWidth / 3 * 2,
            3 * (windowHeight + scoreBoardHeight) / 26 * 25 / 3, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 3, 3);
    stringRGBA(ren, (windowWidth / 3 + 145) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 22 / 3 +
                                                  3 * (windowHeight + scoreBoardHeight) / 26 * 25 / 3) / 2 / 3,
               "Exit game", 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);

    switch (selected) {
        case 1:
            boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 2 / 3, windowWidth / 3 * 2,
                    3 * (windowHeight + scoreBoardHeight) / 26 * 5 / 3, 77, 136, 255, 255);
            SDL_RenderSetScale(ren, 3, 3);
            stringRGBA(ren, (windowWidth / 3 + 115) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 2 / 3 +
                                                          3 * (windowHeight + scoreBoardHeight) / 26 * 5 / 3) / 2 / 3,
                       "Resume game", 255, 255, 255, 255);
            SDL_RenderSetScale(ren, 1, 1);
            break;
        case 2:
            boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 2, windowWidth / 3 * 2,
                    3 * (windowHeight + scoreBoardHeight) / 26 * 3, 77, 136, 255, 255);
            SDL_RenderSetScale(ren, 3, 3);
            stringRGBA(ren, (windowWidth / 3 + 60) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 2 +
                                                         3 * (windowHeight + scoreBoardHeight) / 26 * 3) / 2 / 3,
                       "Start a new game", 255, 255, 255, 255);
            SDL_RenderSetScale(ren, 1, 1);
            break;
        case 3:
            boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 10 / 3, windowWidth / 3 * 2,
                    3 * (windowHeight + scoreBoardHeight) / 26 * 13 / 3, 77, 136, 255, 255);
            SDL_RenderSetScale(ren, 3, 3);
            stringRGBA(ren, (windowWidth / 3 + 115) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 10 / 3 +
                                                          3 * (windowHeight + scoreBoardHeight) / 26 * 13 / 3) / 2 / 3,
                       "Load a game", 255, 255, 255, 255);
            SDL_RenderSetScale(ren, 1, 1);
            break;
        case 4:
            boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 14 / 3, windowWidth / 3 * 2,
                    3 * (windowHeight + scoreBoardHeight) / 26 * 17 / 3, 77, 136, 255, 255);
            SDL_RenderSetScale(ren, 3, 3);
            stringRGBA(ren, (windowWidth / 3 + 140) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 14 / 3 +
                                                          3 * (windowHeight + scoreBoardHeight) / 26 * 17 / 3) / 2 / 3,
                       "Edit keys", 255, 255, 255, 255);
            SDL_RenderSetScale(ren, 1, 1);
            break;
        case 5:
            boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 6, windowWidth / 3 * 2,
                    3 * (windowHeight + scoreBoardHeight) / 26 * 7, 77, 136, 255, 255);
            SDL_RenderSetScale(ren, 3, 3);
            stringRGBA(ren, (windowWidth / 3 + 50) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 6 +
                                                         3 * (windowHeight + scoreBoardHeight) / 26 * 7) / 2 / 3,
                       "Play/Pause sound", 255, 255, 255, 255);
            SDL_RenderSetScale(ren, 1, 1);
            break;
        case 6:
            boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 22 / 3, windowWidth / 3 * 2,
                    3 * (windowHeight + scoreBoardHeight) / 26 * 25 / 3, 77, 136, 255, 255);
            SDL_RenderSetScale(ren, 3, 3);
            stringRGBA(ren, (windowWidth / 3 + 145) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 22 / 3 +
                                                          3 * (windowHeight + scoreBoardHeight) / 26 * 25 / 3) / 2 / 3,
                       "Exit game", 255, 255, 255, 255);
            SDL_RenderSetScale(ren, 1, 1);
            break;
    }
}

void drawStartMenu(SDL_Renderer *ren, int selected) {
    boxRGBA(ren, 0, 0, windowWidth, windowHeight + scoreBoardHeight, 102, 0, 32, 255);

    boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 2 / 3, windowWidth / 3 * 2,
            3 * (windowHeight + scoreBoardHeight) / 26 * 5 / 3, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 3, 3);
    stringRGBA(ren, (windowWidth / 3 + 60) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 2 / 3 +
                                                 3 * (windowHeight + scoreBoardHeight) / 26 * 5 / 3) / 2 / 3,
               "Start a new game", 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);

    boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 2, windowWidth / 3 * 2,
            3 * (windowHeight + scoreBoardHeight) / 26 * 3, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 3, 3);
    stringRGBA(ren, (windowWidth / 3 + 80) / 3,
               (3 * (windowHeight + scoreBoardHeight) / 26 * 2 + 3 * (windowHeight + scoreBoardHeight) / 26 * 3) / 2 /
               3, "Set score limit", 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);

    boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 10 / 3, windowWidth / 3 * 2,
            3 * (windowHeight + scoreBoardHeight) / 26 * 13 / 3, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 3, 3);
    stringRGBA(ren, (windowWidth / 3 + 115) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 10 / 3 +
                                                  3 * (windowHeight + scoreBoardHeight) / 26 * 13 / 3) / 2 / 3,
               "Load a game", 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);

    boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 14 / 3, windowWidth / 3 * 2,
            3 * (windowHeight + scoreBoardHeight) / 26 * 17 / 3, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 3, 3);
    stringRGBA(ren, (windowWidth / 3 + 140) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 14 / 3 +
                                                  3 * (windowHeight + scoreBoardHeight) / 26 * 17 / 3) / 2 / 3,
               "Edit keys", 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);

    boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 6, windowWidth / 3 * 2,
            3 * (windowHeight + scoreBoardHeight) / 26 * 7, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 3, 3);
    stringRGBA(ren, (windowWidth / 3 + 50) / 3,
               (3 * (windowHeight + scoreBoardHeight) / 26 * 6 + 3 * (windowHeight + scoreBoardHeight) / 26 * 7) / 2 /
               3, "Play/Pause sound", 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);

    boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 22 / 3, windowWidth / 3 * 2,
            3 * (windowHeight + scoreBoardHeight) / 26 * 25 / 3, 255, 255, 255, 255);
    SDL_RenderSetScale(ren, 3, 3);
    stringRGBA(ren, (windowWidth / 3 + 145) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 22 / 3 +
                                                  3 * (windowHeight + scoreBoardHeight) / 26 * 25 / 3) / 2 / 3,
               "Exit game", 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 1, 1);

    switch (selected) {
        case 1:
            boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 2 / 3, windowWidth / 3 * 2,
                    3 * (windowHeight + scoreBoardHeight) / 26 * 5 / 3, 77, 136, 255, 255);
            SDL_RenderSetScale(ren, 3, 3);
            stringRGBA(ren, (windowWidth / 3 + 60) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 2 / 3 +
                                                         3 * (windowHeight + scoreBoardHeight) / 26 * 5 / 3) / 2 / 3,
                       "Start a new game", 255, 255, 255, 255);
            SDL_RenderSetScale(ren, 1, 1);
            break;
        case 2:
            boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 2, windowWidth / 3 * 2,
                    3 * (windowHeight + scoreBoardHeight) / 26 * 3, 77, 136, 255, 255);
            SDL_RenderSetScale(ren, 3, 3);
            stringRGBA(ren, (windowWidth / 3 + 80) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 2 +
                                                         3 * (windowHeight + scoreBoardHeight) / 26 * 3) / 2 / 3,
                       "Set score limit", 255, 255, 255, 255);
            SDL_RenderSetScale(ren, 1, 1);
            break;
        case 3:
            boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 10 / 3, windowWidth / 3 * 2,
                    3 * (windowHeight + scoreBoardHeight) / 26 * 13 / 3, 77, 136, 255, 255);
            SDL_RenderSetScale(ren, 3, 3);
            stringRGBA(ren, (windowWidth / 3 + 115) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 10 / 3 +
                                                          3 * (windowHeight + scoreBoardHeight) / 26 * 13 / 3) / 2 / 3,
                       "Load a game", 255, 255, 255, 255);
            SDL_RenderSetScale(ren, 1, 1);
            break;
        case 4:
            boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 14 / 3, windowWidth / 3 * 2,
                    3 * (windowHeight + scoreBoardHeight) / 26 * 17 / 3, 77, 136, 255, 255);
            SDL_RenderSetScale(ren, 3, 3);
            stringRGBA(ren, (windowWidth / 3 + 140) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 14 / 3 +
                                                          3 * (windowHeight + scoreBoardHeight) / 26 * 17 / 3) / 2 / 3,
                       "Edit keys", 255, 255, 255, 255);
            SDL_RenderSetScale(ren, 1, 1);
            break;
        case 5:
            boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 6, windowWidth / 3 * 2,
                    3 * (windowHeight + scoreBoardHeight) / 26 * 7, 77, 136, 255, 255);
            SDL_RenderSetScale(ren, 3, 3);
            stringRGBA(ren, (windowWidth / 3 + 50) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 6 +
                                                         3 * (windowHeight + scoreBoardHeight) / 26 * 7) / 2 / 3,
                       "Play/Pause sound", 255, 255, 255, 255);
            SDL_RenderSetScale(ren, 1, 1);
            break;
        case 6:
            boxRGBA(ren, windowWidth / 3, 3 * (windowHeight + scoreBoardHeight) / 26 * 22 / 3, windowWidth / 3 * 2,
                    3 * (windowHeight + scoreBoardHeight) / 26 * 25 / 3, 77, 136, 255, 255);
            SDL_RenderSetScale(ren, 3, 3);
            stringRGBA(ren, (windowWidth / 3 + 145) / 3, (3 * (windowHeight + scoreBoardHeight) / 26 * 22 / 3 +
                                                          3 * (windowHeight + scoreBoardHeight) / 26 * 25 / 3) / 2 / 3,
                       "Exit game", 255, 255, 255, 255);
            SDL_RenderSetScale(ren, 1, 1);
            break;
    }

    //////////////////////////////////////////////////help for two players
    stringRGBA(ren, 10, windowHeight + scoreBoardHeight - 30, "Save key: f9", 255, 255, 255, 100);
    stringRGBA(ren, 10, windowHeight + scoreBoardHeight - 20,
               "Default key layout: palyer 1: (shoot=m) (forward=up arrow key) (backward= down arrow key) (right=right arrow key) (left=left arrow key)",
               255, 255, 255, 100);
    stringRGBA(ren, 10, windowHeight + scoreBoardHeight - 10,
               "Default key layout: palyer 2: (shoot=1) (forward=w) (backward= s) (right=d) (left=a)", 255, 255, 255,
               100);
}

void drawEditKeyMenu(SDL_Renderer *ren, int status) {
    boxRGBA(ren, 0, 0, windowWidth, windowHeight + scoreBoardHeight, 100, 100, 100, 200);

    if (!status) {
        boxRGBA(ren, windowWidth / 3, (windowHeight + scoreBoardHeight - 200) / 2, windowWidth / 3 * 2,
                (windowHeight + scoreBoardHeight + 200) / 2, 77, 136, 255, 255);
        SDL_RenderSetScale(ren, 2 * windowWidth / winMaxWidth, 2);
        stringRGBA(ren, (windowWidth / 3 + 120) / (2 * windowWidth / winMaxWidth),
                   (windowHeight + scoreBoardHeight - 50) / 2 / (2),
                   "Enter the key you want to edit,", 255, 255, 255, 255);
        stringRGBA(ren, (windowWidth / 3 + 150) / (2 * windowWidth / winMaxWidth),
                   (windowHeight + scoreBoardHeight + 50) / 2 / (2), "then enter the new key.", 255,
                   255, 255, 255);
        SDL_RenderSetScale(ren, 1, 1);
    } else {
        boxRGBA(ren, windowWidth / 3, (windowHeight + scoreBoardHeight - 200) / 2, windowWidth / 3 * 2,
                (windowHeight + scoreBoardHeight + 200) / 2, 255, 102, 102, 255);
        SDL_RenderSetScale(ren, 3 * windowWidth / winMaxWidth, 3);
        stringRGBA(ren, (windowWidth / 3 + 170) / (3 * windowWidth / winMaxWidth),
                   (windowHeight + scoreBoardHeight) / 2 / (3),
                   "Scanning...", 255, 255, 255, 255);
        SDL_RenderSetScale(ren, 1, 1);
    }
}

void drawEditKeyMenuS(SDL_Renderer *ren, int status) {
    if (!status) {
        boxRGBA(ren, windowWidth / 3, (windowHeight + scoreBoardHeight - 200) / 2, windowWidth / 3 * 2,
                (windowHeight + scoreBoardHeight + 200) / 2, 77, 136, 255, 255);
        SDL_RenderSetScale(ren, 2 * windowWidth / winMaxWidth, 3);
        stringRGBA(ren, (windowWidth / 3 + 30) / (2 * windowWidth / winMaxWidth),
                   (windowHeight + scoreBoardHeight - 50) / 2 / (3),
                   "Enter the key you want to edit,", 255, 255, 255, 255);
        stringRGBA(ren, (windowWidth / 3 + 80) / (2 * windowWidth / winMaxWidth),
                   (windowHeight + scoreBoardHeight + 50) / 2 / (3), "then enter the new key.", 255,
                   255, 255, 255);
        SDL_RenderSetScale(ren, 1, 1);
    } else {
        boxRGBA(ren, windowWidth / 3, (windowHeight + scoreBoardHeight - 200) / 2, windowWidth / 3 * 2,
                (windowHeight + scoreBoardHeight + 200) / 2, 255, 102, 102, 255);
        SDL_RenderSetScale(ren, 3 * windowWidth / winMaxWidth, 4);
        stringRGBA(ren, (windowWidth / 3 + 150) / (3 * windowWidth / winMaxWidth),
                   (windowHeight + scoreBoardHeight) / 2 / (4),
                   "Scanning...", 255, 255, 255, 255);
        SDL_RenderSetScale(ren, 1, 1);
    }
}

void winnerScreen(int winner, SDL_Renderer *ren, Tank *tanks) {
    SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
    SDL_RenderClear(ren);
    for (int i = 0; i < 300; i++) {
        tanks[winner].x = rand() % windowWidth;
        tanks[winner].y = rand() % (windowHeight + scoreBoardHeight);
        tanks[winner].angel = rand() % 360;

        for (double i1 = -tank_pipe_span;
             i1 < tank_pipe_span; i1 += (double) tank_pipe_span / tank_pipe_howmany_lines) {
            aalineRGBA(ren, tanks[winner].x, tanks[winner].y,
                       (cos(degtorad(tanks[winner].angel + i1)) * tank_pipe_length + tanks[winner].x),
                       (sin(degtorad(tanks[winner].angel + i1)) * tank_pipe_length + tanks[winner].y), 0,
                       0, 0, 255);
        }

        filledCircleRGBA(ren, tanks[winner].x, tanks[winner].y, tankradius - 1, tanks[winner].color.r,
                         tanks[winner].color.g,
                         tanks[winner].color.b, 255);
        aacircleRGBA(ren, tanks[winner].x, tanks[winner].y, tankradius - 1, tanks[winner].color.r,
                     tanks[winner].color.g,
                     tanks[winner].color.b, 255);
        aacircleRGBA(ren, tanks[winner].x, tanks[winner].y, tankradius, tanks[winner].color.r, tanks[winner].color.g,
                     tanks[winner].color.b, 255);
    }

    SDL_RenderSetScale(ren, 25, 25);
    stringRGBA(ren, 8, windowHeight / 2 / 30, "Winner", 0, 0, 0, 255);
    SDL_RenderSetScale(ren, 1, 1);
}

void drawWinLimitMenu(SDL_Renderer *ren, int scoreLimit) {
    boxRGBA(ren, 0, 0, windowWidth, windowHeight + scoreBoardHeight, 102, 0, 32, 255);

    boxRGBA(ren, windowWidth / 4, (windowHeight + scoreBoardHeight - 200) / 2, windowWidth / 4 * 3,
            (windowHeight + scoreBoardHeight + 200) / 2, 77, 136, 255, 255);
    SDL_RenderSetScale(ren, 2 * windowWidth / winMaxWidth, 2);
    stringRGBA(ren, (windowWidth / 4 + 100) / (2 * windowWidth / winMaxWidth),
               (windowHeight + scoreBoardHeight - 100) / 2 / (2),
               "Enter score limit(nothing for infinit)", 255, 255, 255, 255);
    char temp[100] = {0};
    if (scoreLimit != -1 && scoreLimit != 0)
        sprintf(temp, "%d", scoreLimit);
    stringRGBA(ren, (windowWidth / 3 + 250 - log(scoreLimit) * 4) / (2 * windowWidth / winMaxWidth),
               (windowHeight + scoreBoardHeight + 50) / 2 / (2), temp, 255, 204, 0, 255);
    SDL_RenderSetScale(ren, 1, 1);

    stringRGBA(ren,10,windowHeight+scoreBoardHeight-40,"You can enter these codes after desired score limit to enter a mod:",255,255,255,100);
    stringRGBA(ren,10,windowHeight+scoreBoardHeight-30,"Laser only mod: 1231",255,255,255,100);
    stringRGBA(ren,10,windowHeight+scoreBoardHeight-20,"Shotgun only mod: 1234",255,255,255,100);
    stringRGBA(ren,10,windowHeight+scoreBoardHeight-10,"Mine only mod: 1235",255,255,255,100);
}