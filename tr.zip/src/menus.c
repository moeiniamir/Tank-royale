//
// Created by amir on 1/23/19.
//

#include <SDL_timer.h>
#include <SDL2_gfxPrimitives.h>
#include "menus.h"
#include "struct.h"
#include "draw.h"
#include "input.h"
#include "fileToHandleFiles.h"
#include "logic.h"
#include "singers.h"

void openEditMenu(SDL_Renderer *ren, Tank *tanks, Bullet *firstBullet) {
    int status = 0;
    while (1) {
        int start_of_iteration_time = SDL_GetTicks();

        int input = editKeyMenuInputAnalysis();
        if (input == -1)
            return;
        else if (input == -2)
            exit(0);
        else if (input) {
            if (!status)
                for (int i = 0; i < number_of_players; i++) {
                    if (tanks[i].lo.shoot == input || tanks[i].lo.up == input || tanks[i].lo.down == input ||
                        tanks[i].lo.right == input || tanks[i].lo.left == input) {
                        status = input;
                    }
                }
            else {
                for (int i = 0; i < number_of_players; i++) {
                    if (tanks[i].lo.shoot == status)
                        tanks[i].lo.shoot = input;
                    if (tanks[i].lo.right == status)
                        tanks[i].lo.right = input;
                    if (tanks[i].lo.left == status)
                        tanks[i].lo.left = input;
                    if (tanks[i].lo.up == status)
                        tanks[i].lo.up = input;
                    if (tanks[i].lo.down == status)
                        tanks[i].lo.down = input;
                }
                status = 0;
            }
        }

        if (firstBullet != 1) {
            draw_all(ren, tanks, firstBullet);
            drawEditKeyMenu(ren, status);
        } else {
            boxRGBA(ren, 0, 0, windowWidth, windowHeight + scoreBoardHeight, 102, 0, 32, 255);
            drawEditKeyMenuS(ren, status);
        }
        SDL_RenderPresent(ren);

        while (SDL_GetTicks() - start_of_iteration_time < 1000.0 / fps) {
            SDL_Delay(10);
        }
    }
}

void openMenu(SDL_Renderer *ren, Bullet **firstBullet, Tank *tanks) {
    int menuStartTime=SDL_GetTicks();
    Mix_Resume(menuMusic.channel);

    int selected = 1;
    int stay=1;
    while (stay) {
        int start_of_iteration_time = SDL_GetTicks();

        int key = 0;
        if ((key = menuInputAnalysis(&selected)) == 3) {
            break;
        } else if (key == 2) {
            switch (selected) {
                case 1:
                    stay=0;
                    break;
                case 2:
                    for (int i = 0; i < number_of_players; i++) {
                        tanks[i].score = 0;
                        tanks[i].exists = 0;
                    }
                    stay=0;
                    break;
                case 3:
                    if (load(tanks, firstBullet)) {
                        stay=0;
                        menuStartTime=SDL_GetTicks();
                    }
                    break;
                case 4:
                    openEditMenu(ren, tanks, *firstBullet);
                    break;
                case 5:
                    switchSound();
                    break;
                case 6:
                    exit(0);
            }
        } else if (key == 1) {
            if (selected == 0)
                selected = 6;
            if (selected == 7)
                selected = 1;
        }


        draw_all(ren, tanks, *firstBullet);
        drawMenu(ren, selected);
        SDL_RenderPresent(ren);

        while (SDL_GetTicks() - start_of_iteration_time < 1000.0 / fps) {
            SDL_Delay(10);
        }
    }

    Mix_Pause(menuMusic.channel);
    fixBirthdays(*firstBullet,SDL_GetTicks()-menuStartTime);
}

void scoreLimitMenu(SDL_Renderer *ren, int *scoreLimit) {
    while (1) {
        int start_of_iteration_time = SDL_GetTicks();

        int input = editKeyMenuInputAnalysis();
        if (input == -1 || input == SDL_SCANCODE_RETURN) {
            if (*scoreLimit == 0)
                *scoreLimit = -1;
            return;
        } else if (input == -2)
            exit(0);
        else if (input <= SDL_SCANCODE_0 && input >= SDL_SCANCODE_1) {
            if (*scoreLimit == -1)
                *scoreLimit = 0;
            *scoreLimit = *scoreLimit * 10 + input - (input == SDL_SCANCODE_0 ? SDL_SCANCODE_0 : SDL_SCANCODE_1 - 1);
        } else if (input == SDL_SCANCODE_BACKSPACE) {
            *scoreLimit /= 10;
        }

        drawWinLimitMenu(ren, *scoreLimit);
        SDL_RenderPresent(ren);

        while (SDL_GetTicks() - start_of_iteration_time < 1000.0 / fps) {
            SDL_Delay(10);
        }
    }
}

void openStartMenu(SDL_Renderer *ren, Tank *tanks, int *scoreLimit, Bullet **firstBullet) {
    int selected = 1;
    while (1) {
        int start_of_iteration_time = SDL_GetTicks();

        int key = menuInputAnalysis(&selected);
        if (key == 2) {
            switch (selected) {
                case 1:
                    return;
                case 2:
                    scoreLimitMenu(ren, scoreLimit);
                    break;
                case 3:
                    if (load(tanks, firstBullet)) {
                        return;
                    }
                    break;
                case 4:
                    openEditMenu(ren, tanks, 1);
                    break;
                case 5:
                    switchSound();
                    break;
                case 6:
                    exit(0);
            }
        } else if (key == 1) {
            if (selected == 0)
                selected = 6;
            if (selected == 7)
                selected = 1;
        }

        drawStartMenu(ren, selected);
        SDL_RenderPresent(ren);

        while (SDL_GetTicks() - start_of_iteration_time < 1000.0 / fps) {
            SDL_Delay(10);
        }
    }
}
