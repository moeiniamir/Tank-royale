//
// Created by amir on 1/29/19.
//
#include "singers.h"
#include <SDL_mixer.h>
#include "struct.h"

void loadVulumes(void){
    Mix_VolumeChunk(buttonch, 50);
    Mix_VolumeChunk(buttonse, 50);
    Mix_VolumeChunk(grenex, 20);
    Mix_VolumeChunk(health, 100);
    Mix_VolumeChunk(hurt, 50);
    Mix_VolumeChunk(laser, 50);
    Mix_VolumeChunk(minedet, 50);
    Mix_VolumeChunk(mineput, 80);
    Mix_VolumeChunk(pu, 50);
    Mix_VolumeChunk(raydelay, 500);
    Mix_VolumeChunk(rayself, 50);
    Mix_VolumeChunk(shoots, 150);
    Mix_VolumeChunk(shotguns, 20);
    Mix_VolumeChunk(tankex, 300);
    Mix_VolumeChunk(winnerbell, 50);
    Mix_VolumeChunk(newpu, 100);
    Mix_VolumeChunk(startMusic.music,100);
    Mix_VolumeChunk(menuMusic.music,100);
}

void loadMedia(void) {
    buttonch = Mix_LoadWAV("sounds/buttonch.wav");          //0

    buttonse = Mix_LoadWAV("sounds/buttonse.wav");          //1

    grenex = Mix_LoadWAV("sounds/grenex.wav");              //2

    health = Mix_LoadWAV("sounds/health.wav");              //3

    hurt = Mix_LoadWAV("sounds/hurt.aiff");                 //4

    laser = Mix_LoadWAV("sounds/laser.wav");                //5

    minedet = Mix_LoadWAV("sounds/minedet.wav");            //6

    mineput = Mix_LoadWAV("sounds/mineput.wav");            //7

    pu = Mix_LoadWAV("sounds/pu.wav");                      //8

    raydelay = Mix_LoadWAV("sounds/raydelay.ogg");          //9

    rayself = Mix_LoadWAV("sounds/rayself.wav");            //10

    shoots = Mix_LoadWAV("sounds/shoots.aiff");             //11

    shotguns = Mix_LoadWAV("sounds/shotguns.wav");          //12

    tankex = Mix_LoadWAV("sounds/tankex.wav");              //13

    winnerbell = Mix_LoadWAV("sounds/winnerbell.aiff");     //14

    newpu = Mix_LoadWAV("sounds/newpu.wav");                  //15

    startMusic.music = Mix_LoadWAV("sounds/startmusic.mp3");
    startMusic.channel = Mix_PlayChannel(-1, startMusic.music, -1);
    Mix_Pause(startMusic.channel);

    menuMusic.music = Mix_LoadWAV("sounds/menumusic.mp3");
    menuMusic.channel = Mix_PlayChannel(-1, menuMusic.music, -1);
    Mix_Pause(menuMusic.channel);

    loadVulumes();
}

void playEff(int which) {
    static int minedetch = -1;

    switch (which) {
        case 0:
            Mix_PlayChannel(-1, buttonch, 0);
            break;
        case 1:
            Mix_PlayChannel(-1, buttonse, 0);
            break;
        case 2:
            Mix_PlayChannel(-1, grenex, 0);
            break;
        case 3:
            Mix_PlayChannel(-1, health, 0);
            break;
        case 4:
            Mix_PlayChannel(-1, hurt, 0);
            break;
        case 5:
            Mix_PlayChannel(-1, laser, 0);
            break;
        case 6:
            if (minedetch == -1 || !Mix_Playing(minedetch) ||
                (Mix_Playing(minedetch) && Mix_GetChunk(minedetch) != minedet)) {
                minedetch = Mix_PlayChannel(-1, minedet, 0);
            }
            break;
        case 7:
            Mix_PlayChannel(-1, mineput, 0);
            break;
        case 8:
            Mix_PlayChannel(-1, pu, 0);
            break;
        case 9:
            Mix_PlayChannelTimed(-1, raydelay, 0, ray_delay);
            break;
        case 10:
            Mix_PlayChannelTimed(-1, rayself, 0, ray_time);
            break;
        case 11:
            Mix_PlayChannel(-1, shoots, 0);
            break;
        case 12:
            Mix_PlayChannel(-1, shotguns, 0);
            break;
        case 13:
            Mix_PlayChannel(-1, tankex, 0);
            break;
        case 14:
            Mix_PlayChannel(-1, winnerbell, 0);
            break;
        case 15:
            Mix_PlayChannel(-1, newpu, 0);
            break;
    }
}

void switchSound(void){
    if(mute==0){
        Mix_Volume(-1,0);
        mute=1;
    } else{
        Mix_Volume(-1,128);
        mute=0;
    }
}