//
// Created by amir on 1/29/19.
//

#ifndef TR_SINGERS_H
#define TR_SINGERS_H

void loadMedia(void);

void playEff(int which);

void switchSound(void);

#endif //TR_SINGERS_H
