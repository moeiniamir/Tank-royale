#ifndef draw_h
#define draw_h

#include "struct.h"

void draw_all(SDL_Renderer *, Tank *, Bullet *);

void draw_bullets(SDL_Renderer *, Bullet *);

void draw_tanks(SDL_Renderer *, Tank *);

void draw_walls(SDL_Renderer *);

void drawMenu(SDL_Renderer *ren,int selected);

void drawStartMenu(SDL_Renderer *ren,int selected);

void drawEditKeyMenu(SDL_Renderer *ren, int status);

void winnerScreen(int winner,SDL_Renderer *ren,Tank *tanks);

void drawWinLimitMenu(SDL_Renderer *ren, int scoreLimit);

void drawEditKeyMenuS(SDL_Renderer *ren, int status);

#endif