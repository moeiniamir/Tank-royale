#ifndef input_h
#define input_h

int input_analysis(Tank *, Bullet **,SDL_Renderer *);

int menuInputAnalysis(int *selected);

int editKeyMenuInputAnalysis(void);

#endif