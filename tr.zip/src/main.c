#include <stdio.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include "struct.h"
#include "create.h"
#include "input.h"
#include "logic.h"
#include "coll.h"
#include "draw.h"
#include "wallgen.h"
#include "menus.h"
#include "powerups.h"
#include <time.h>
#include <SDL_mixer.h>
#include "singers.h"

int main() {
    srand(time(NULL));
    int quit = 0;
    Tank *tanks = create_tank();
    Bullet *first_bullet_adress = NULL;

    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    Mix_OpenAudio(MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT, 2, 2048);
    loadMedia();

    while (1) {
        int firstTimeAlone = 1;

        static int isStart = 1;
        if (isStart) {
            Mix_Resume(startMusic.channel);

            windowWidth = winMaxWidth;
            windowHeight = winMaxHeight - scoreBoardHeight;
            SDL_Window *tempwin = SDL_CreateWindow("Tank Royale", window_x, window_y, windowWidth,
                                                   windowHeight + scoreBoardHeight,
                                                   SDL_WINDOW_OPENGL);
            SDL_Renderer *tempren = SDL_CreateRenderer(tempwin, -1, SDL_RENDERER_ACCELERATED);

            openStartMenu(tempren, tanks, &scoreLimit, &first_bullet_adress);

            gfxPrimitivesSetFont(NULL, 0, 0);
            SDL_DestroyRenderer(tempren);
            SDL_DestroyWindow(tempwin);
            isStart = 0;
            Mix_Pause(startMusic.channel);
        }

        if (!walls) {
            createWalls();
            initTanks(tanks, windowWidth, windowHeight);
            first_bullet_adress = NULL;
        }

        SDL_Window *win = SDL_CreateWindow("Tank Royale", window_x, window_y, windowWidth,
                                           windowHeight + scoreBoardHeight,
                                           SDL_WINDOW_OPENGL);
        SDL_Renderer *ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);

        while (1) {
            int start_of_iteration_time = SDL_GetTicks();

            SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
            SDL_RenderClear(ren);

            if (!input_analysis(tanks, &first_bullet_adress, ren)) {
                quit = 1;
                break;
            }

            SDL_SetWindowSize(win, windowWidth, windowHeight + scoreBoardHeight);

            manage_bullets(&first_bullet_adress);
            powerUpsBG(&first_bullet_adress, tanks);

            int winnerState = checkWhatIsGoingOn(tanks, first_bullet_adress);

            draw_all(ren, tanks, first_bullet_adress);
            SDL_RenderPresent(ren);

            if (winnerState == 1) {
                static int firstTimeAloneTime;
                if (firstTimeAlone) {
                    firstTimeAloneTime = SDL_GetTicks();
                    firstTimeAlone = 0;
                }
                if (SDL_GetTicks() - firstTimeAloneTime > winner_delay) {
                    addScore(tanks);

                    int winner = checkScoreLimit(tanks, scoreLimit);
                    if (winner + 1) {
                        winnerScreen(winner, ren, tanks);
                        SDL_RenderPresent(ren);
                        playEff(14);
                        SDL_Delay(winnerScreenTime);
                        for (int i = 0; i < number_of_players; i++) {
                            tanks[i].score = 0;
                        }
                        isStart = 1;
                        break;
                    }

                    SDL_Delay(screenshotTime);
                    break;
                }
            } else if (winnerState == 2) {
                SDL_Delay(screenshotTime);
                break;
            }

            while (SDL_GetTicks() - start_of_iteration_time < 1000.0 / fps) {
                SDL_Delay(10);
            }
        }

        gfxPrimitivesSetFont(NULL, 0, 0);
        SDL_DestroyRenderer(ren);
        SDL_DestroyWindow(win);
        garbageCollector(&first_bullet_adress);
        remove("rgm.txt");

        if (quit)
            break;
    }
    SDL_Quit();
}
