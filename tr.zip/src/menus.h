//
// Created by amir on 1/23/19.
//

#ifndef TR_MENUS_H
#define TR_MENUS_H

#include <SDL_system.h>
#include "struct.h"

void openMenu(SDL_Renderer *ren,Bullet **firstBullet,Tank *tanks);

void openStartMenu(SDL_Renderer *ren,Tank *tanks,int *scoreLimit,Bullet **firstBullet);

#endif //TR_MENUS_H
