#ifndef wallgen_h
#define wallgen_h

void createWalls(void);

#endif