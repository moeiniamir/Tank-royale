#include "powerups.h"
#include "struct.h"
#include "create.h"
#include "logic.h"
#include "coll.h"
#include <SDL2/SDL.h>
#include <stdlib.h>
#include "logic.h"
#include <math.h>
#include "coll.h"
#include "singers.h"

void laserTrail(Bullet **firstBullet, Tank *tanks) {

    for (int i = 0; i < number_of_players; i++) {

        for (; *firstBullet; firstBullet = &(*firstBullet)->next);

        if (tanks[i].powerUP == 1) {
            for (int i1 = 0; i1 < 10; i1++) {
                create_bullet(tanks + i, firstBullet, 1);

                for (int i2 = 0; i2 < 7; i2++) {
                    move_bullets(*firstBullet);
                    reflectBullet(*firstBullet);
                }
            }
        }
    }
}

void ray(Tank *tanks, Bullet **firstBullet) { ////////////////////////hugely two tanks only!!!
    for (int i = 0; i < number_of_players; i++) {
        if (abs((int) SDL_GetTicks() - tanks[i].rayStartTime - ray_delay) < 1000 / fps) {
            playEff(10);

            for (; *firstBullet; firstBullet = &(*firstBullet)->next);

            for (int i1 = 0; i1 < 1000; i1++) {
                create_bullet(tanks + i, firstBullet, 3);

                for (Bullet *worm = *firstBullet; worm; worm = worm->next) {

                    double angleWeWant = (tanks[i ? 0 : 1].x - worm->x) ? radtodeg(
                            atan((tanks[i ? 0 : 1].y - worm->y) / (tanks[i ? 0 : 1].x - worm->x)))
                                                                        : -90;
                    if (tanks[i ? 0 : 1].x - worm->x < 0) {
                        angleWeWant += 180;
                    }

                    double diff = worm->angel - angleWeWant;
                    if (diff > 360)
                        diff -= 360;

                    if (fabs(diff) < 180) {
                        if (diff > 0)
                            worm->angel -= ray_curvature;
                        else if (diff < 0)
                            worm->angel += ray_curvature;
                    } else if (fabs(diff) > 180) {
                        if (diff > 0)
                            worm->angel += ray_curvature;
                        else if (diff < 0)
                            worm->angel -= ray_curvature;
                    }
                }

                move_bullets(*firstBullet);
            }

            for (; *firstBullet; firstBullet = &(*firstBullet)->next) {
                (*firstBullet)->speed = 0;
            }
        }
        if (abs((int)SDL_GetTicks() - tanks[i].rayStartTime - (ray_time + ray_delay)) < 2000 / fps) {
            tanks[i].powerUP = 0;
        }
    }
}

void createPU(int type) {
    playEff(15);

    Powerup *new = malloc(sizeof(Powerup));
    new->next = puHead;
    puHead = new;

    new->eaten = 0;
    new->type = type;
    do {
        new->x = rand() % windowWidth;
        new->y = rand() % windowHeight;
    } while (wall_coll(new->x, new->y, PUradius));
}

void randomPUCreator(void) {
    static int nextTime = 0;
    static char typeArr[100000]; ////////////////////////depended on the chances this can be smaller
    static int NTA = 0;
    if (nextTime == 0) {
        for (int i = 0; i < health_chance; i++, NTA++) {
            typeArr[NTA] = 0;
        }
        for (int i = 0; i < laser_chance; i++, NTA++) {
            typeArr[NTA] = 1;
        }
        for (int i = 0; i < ray_chance; i++, NTA++) {
            typeArr[NTA] = 2;
        }
        for (int i = 0; i < gren_chance; i++, NTA++) {
            typeArr[NTA] = 3;
        }
        for (int i = 0; i < shotgun_chance; i++, NTA++) {
            typeArr[NTA] = 4;
        }
        for (int i = 0; i < mine_chance; i++, NTA++) {
            typeArr[NTA] = 5;
        }
    }

    int shouldSetTime = 0;
    if (fabs(SDL_GetTicks() - nextTime) < 2000 / fps) {
        createPU(typeArr[rand() % NTA]);
        shouldSetTime = 1;
    } else if ((int) SDL_GetTicks() - nextTime > 2000 / fps) {
        shouldSetTime = 1;
    }
    if (shouldSetTime) {
        nextTime += rand() % (random_time_high - random_time_low) + random_time_low;
    }
}

void dasteRahmat(Tank *tanks) {
    for (Powerup *worm = puHead; worm; worm = worm->next) {
        for (int i = 0; i < number_of_players; i++) {
            if (sqrt(
                    (worm->x - tanks[i].x) * (worm->x - tanks[i].x) + (worm->y - tanks[i].y) * (worm->y - tanks[i].y)) <
                PUradius + tankradius && (tanks[i].powerUP == 0 || worm->type == 0)) {
                if (worm->type == 0 && tanks[i].exists) {
                    playEff(3);

                    tanks[i].exists++;
                } else {
                    playEff(8);

                    tanks[i].powerUP = worm->type;
                }
                worm->eaten = 1;
                break;
            }
        }
    }
}

void killEatenPU(void) {
    for (Powerup **worm = &puHead; *worm;) {
        int killed = 0;
        if ((*worm)->eaten == 1) {
            Powerup *backup = *worm;
            (*worm) = (*worm)->next;
            free(backup);
            killed = 1;
        }
        if (!killed) {
            worm = &(*worm)->next;
        }
    }
}

void powerUpsBG(Bullet **firstBullet, Tank *tanks) {
    laserTrail(firstBullet, tanks);
    ray(tanks, firstBullet);

    dasteRahmat(tanks);
    if (scoreLimit % 10000 != 1231 && scoreLimit % 10000 != 1234 && scoreLimit % 10000 != 1235)
        randomPUCreator();
    killEatenPU();
}

void detonateGren(Bullet **firstBullet, Bullet *gren) {
    playEff(2);
    for (int i = 0; i < frag_number; i++) {
        create_bullet(gren->father, firstBullet, 5);
        (*firstBullet)->x = gren->x;
        (*firstBullet)->y = gren->y;
        (*firstBullet)->angel = 360.0 / frag_number * i;
    }
}

void shoot(Tank *tanks,int which, Bullet **firstBullet) {
    Tank *tank=tanks+which;
    switch (tank->powerUP) {
        case 0:
            create_bullet(tank, firstBullet, 0);
            break;
        case 1:
            playEff(5);

            for (; *firstBullet; firstBullet = &(*firstBullet)->next);
            for (int i1 = 0; i1 < 200; i1++) {
                create_bullet(tank, firstBullet, 2);
                move_bullets(*firstBullet);
                reflectBullet(*firstBullet);
                if (killWithBullet(tanks, *firstBullet)) {
                    break;
                }

                if (i1 == 0)
                    (*firstBullet)->isTipOfLaser = 1;
            }
            for (; *firstBullet; firstBullet = &(*firstBullet)->next) {
                (*firstBullet)->speed = 0;
            }
            if (scoreLimit % 10000 != 1231)
                tank->powerUP = 0;
            break;
        case 2:
            playEff(9);

            if (SDL_GetTicks() - tank->rayStartTime > ray_delay + ray_time) {
                tank->rayStartTime = SDL_GetTicks();
            }
            break;
        case 3:
            playEff(11);

            create_bullet(tank, firstBullet, 4);
            tank->powerUP = 33;
            break;
        case 33:
            for (Bullet *worm = *firstBullet; worm; worm = worm->next) {
                if (worm->father == tank && worm->type == 4) {
                    worm->birthday -= bullet_lifetime;
                    break;
                }
            }
            tank->powerUP = 0;
            break;
        case 4:
            playEff(12);

            for (int i = 0; i < shotgun_number; i++) {
                create_bullet(tank, firstBullet, 6);
                (*firstBullet)->angel += shotgun_spread * ((i % 2) ? -i / 2 : (i + 1) / 2);
            }
            if (scoreLimit % 10000 != 1234)
                tank->powerUP = 0;
            break;
        case 5:
            playEff(7);

            create_bullet(tank, firstBullet, 7);

            if (scoreLimit % 10000 != 1235)
                tank->mineCharge--;

            if(!tank->mineCharge){
                tank->powerUP=0;
                tank->mineCharge=mine_charge;
            }
            break;
    }
}