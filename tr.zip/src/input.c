#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <stdio.h>
#include "logic.h"
#include "struct.h"
#include "create.h"
#include "menus.h"
#include "powerups.h"
#include <stdlib.h>
#include "fileToHandleFiles.h"
#include "singers.h"

int input_analysis(Tank *tanks, Bullet **first_bullet_adress_adress, SDL_Renderer *ren) {
    SDL_PumpEvents();

    const Uint8 *pressed = SDL_GetKeyboardState(NULL);

    if (SDL_GetTicks() - tanks[0].rayStartTime >
        ray_time + ray_delay + ray_frames_after_finish_that_i_dont_know_why_exitst * 1000 / fps) {
        if (pressed[tanks[0].lo.up])
            if (tanks[0].exists)
                move_tank('u', tanks + 0);
        if (pressed[tanks[0].lo.down])
            if (tanks[0].exists)
                move_tank('d', tanks + 0);
        if (pressed[tanks[0].lo.right])
            if (tanks[0].exists)
                move_tank('r', tanks + 0);
        if (pressed[tanks[0].lo.left])
            if (tanks[0].exists)
                move_tank('l', tanks + 0);
        if (pressed[tanks[0].lo.shoot]) {
            if (!(tanks + 0)->shootPressed) {
                if (tanks[0].exists)
                    shoot(tanks , 0, first_bullet_adress_adress);
                (tanks + 0)->shootPressed = 1;
            }
        } else
            (tanks + 0)->shootPressed = 0;
    }

    if (SDL_GetTicks() - tanks[1].rayStartTime >
        ray_time + ray_delay + ray_frames_after_finish_that_i_dont_know_why_exitst * 1000 / fps) {
        if (pressed[tanks[1].lo.up])
            if (tanks[1].exists)
                move_tank('u', tanks + 1);
        if (pressed[tanks[1].lo.down])
            if (tanks[1].exists)
                move_tank('d', tanks + 1);
        if (pressed[tanks[1].lo.right])
            if (tanks[1].exists)
                move_tank('r', tanks + 1);
        if (pressed[tanks[1].lo.left])
            if (tanks[1].exists)
                move_tank('l', tanks + 1);
        if (pressed[tanks[1].lo.shoot]) {
            if (!(tanks + 1)->shootPressed) {
                if (tanks[1].exists)
                    shoot(tanks , 1, first_bullet_adress_adress);
                (tanks + 1)->shootPressed = 1;
            }
        } else
            (tanks + 1)->shootPressed = 0;
    }

    SDL_Event event;
    SDL_PollEvent(&event);

    if (event.type == SDL_QUIT)
        return 0;
    if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) {
        openMenu(ren, first_bullet_adress_adress, tanks);
    }
    if(event.type==SDL_KEYDOWN && event.key.keysym.sym==SDLK_F9){
        save(tanks,*first_bullet_adress_adress);
    }

    return 1;
}

int menuInputAnalysis(int *selected) {
    SDL_Event event;
    SDL_PollEvent(&event);

    if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_UP) {
        playEff(0);

        *selected -= 1;
        return 1;
    }
    if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_DOWN) {
        playEff(0);

        *selected += 1;
        return 1;
    }
    if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) {
        return 3;
    }
    if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_RETURN) {
        playEff(1);

        return 2;
    }
    if (event.type == SDL_QUIT) {
        *selected = 6;
        return 2;
    }

    return 0;
}

int editKeyMenuInputAnalysis(void) {
    SDL_Event event;
    SDL_PollEvent(&event);

    if (event.type == SDL_QUIT)
        return -2;
    if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE)
        return -1;
    if (event.type == SDL_KEYDOWN) {
        return event.key.keysym.scancode;
    }
    return 0;
}

