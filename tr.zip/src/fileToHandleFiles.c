//
// Created by amir on 1/28/19.
//

#include "fileToHandleFiles.h"
#include <time.h>
#include <stdio.h>
#include <nfd.h>
#include <stdlib.h>
#include <SDL_keycode.h>
#include "logic.h"
#include <SDL2/SDL.h>

void save(Tank *tanks,
          Bullet *bulletHead) {////////constants should be the same in save and load. of course they are in the final release!
    time_t now = time(0);
    struct tm *timef = localtime(&now);

    char name[100];
    sprintf(name, "%d-%d-%d %d-%d-%d.tr", timef->tm_year + 1900, timef->tm_mon, timef->tm_mday, timef->tm_hour,
            timef->tm_min, timef->tm_sec);
    FILE *file = fopen(name, "w+");

    fwrite(&scoreLimit,sizeof(int),1,file);

    fwrite(&windowWidth, sizeof(int), 1, file);
    fwrite(&windowHeight, sizeof(int), 1, file);

    fwrite(tanks, sizeof(Tank), number_of_players, file);

    if(walls) {
        for (Wall *worm = walls; worm; worm = worm->next) {
            fwrite(worm, sizeof(Wall), 1, file);
        }
    } else{
        Wall temp;
        temp.next=1;
        fwrite(&temp,sizeof(Wall),1,file);
    }

    if(bulletHead) {
        for (Bullet *worm = bulletHead; worm; worm = worm->next) {
            Bullet temp=*worm;
            temp.birthday=SDL_GetTicks()-worm->birthday;
            fwrite(&temp, sizeof(Bullet), 1, file);
            for(int i=0;i<number_of_players;i++){
                if(tanks+i==worm->father){
                    fwrite(&i,sizeof(int),1,file);
                    break;
                }
            }
        }
    } else{
        Bullet temp;
        temp.next=1;
        fwrite(&temp,sizeof(Bullet),1,file);
    }

    if(puHead) {
        for (Powerup *worm = puHead; worm; worm = worm->next) {
            fwrite(worm, sizeof(Powerup), 1, file);
        }
    } else{
        Powerup temp;
        temp.next=1;
        fwrite(&temp,sizeof(Powerup),1,file);
    }

    fclose(file);
}

int load(Tank *tanks, Bullet **bulletHead) {
    nfdchar_t *path = NULL;
    nfdresult_t result = NFD_OpenDialog("tr", NULL, &path);

    if ( result == NFD_OKAY ) {
        garbageCollector(bulletHead);

        FILE *file=fopen(path,"r");

        fread(&scoreLimit,sizeof(int),1,file);

        fread(&windowWidth,sizeof(int),1,file);
        fread(&windowHeight,sizeof(int),1,file);

        fread(tanks,sizeof(Tank),number_of_players,file);

        Wall *neww;
        while(1){
            neww=calloc(1,sizeof(Wall));
            fread(neww,sizeof(Wall),1,file);
            void *bu=neww->next;
            if(bu!=1){
                neww->next=walls;
                walls=neww;
            } else{
                free(neww);
            }

            if(bu==1 || bu==0){
                break;
            }
        }

        Bullet *newb;
        while(1){
            newb=calloc(1,sizeof(Bullet));
            fread(newb,sizeof(Bullet),1,file);
            void *bu=newb->next;
            if(bu!=1){
                newb->next=*bulletHead;
                *bulletHead=newb;

                int ifather;
                fread(&ifather,sizeof(int),1,file);
                newb->father=&tanks[ifather];

                newb->birthday=SDL_GetTicks()-newb->birthday;
                if(newb->type==7){
                    newb->mineDetect=SDL_GetTicks();
                }
            } else{
                free(newb);
            }

            if(bu==1 || bu==0){
                break;
            }
        }

        Powerup *newp;
        while(1){
            newp=calloc(1,sizeof(Powerup));
            fread(newp,sizeof(Powerup),1,file);
            void *bu=newp->next;
            if(bu!=1){
                newp->next=puHead;
                puHead=newp;
            } else{
                free(newp);
            }

            if(bu==1 || bu==0){
                break;
            }
        }

        free(path);
        fclose(file);
        return 1;
    }
    else {
        return 0;
    }
}