#include "struct.h"
#include <math.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include "logic.h"

int onSeg(double x1, double y1, double x2, double y2, double x3, double y3) {
    if (y3 >= (y1 > y2 ? y2 : y1) && y3 <= (y1 > y2 ? y1 : y2) && x3 >= (x1 > x2 ? x2 : x1) &&
        x3 <= (x1 > x2 ? x1 : x2))
        return 1;
    return 0;
}

int orientation(double x1, double y1, double x2, double y2, double x3, double y3) {
    double tmp = (x3 - x2) * (y2 - y1) - (y3 - y2) * (x2 - x1);
    if (!tmp) return 0;
    return tmp > 0 ? 1 : 2;
}

int pipeColl(Tank *tank) {
    Wall *wall_scroller = walls;
    double x21 = tank->x + cos(degtorad(tank->angel + tank_pipe_span))*tank_pipe_length;
    double y21 = tank->y + sin(degtorad(tank->angel + tank_pipe_span))*tank_pipe_length;
    double x22 = tank->x + cos(degtorad(tank->angel - tank_pipe_span))*tank_pipe_length;
    double y22 = tank->y + sin(degtorad(tank->angel - tank_pipe_span))*tank_pipe_length;

    while (wall_scroller) {
        double line_x1, line_y1, line_x2, line_y2;
        int o1, o2, o3, o4;
        line_x1 = wall_scroller->x1 - ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y1 = wall_scroller->y1 - ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        line_x2 = wall_scroller->x1 + ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y2 = wall_scroller->y1 + ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        o1 = orientation(x21, y21, tank->x, tank->y, line_x1, line_y1);
        o2 = orientation(x21, y21, tank->x, tank->y, line_x2, line_y2);
        o3 = orientation(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y);
        o4 = orientation(line_x1, line_y1, line_x2, line_y2, x21, y21);
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (!o1 && onSeg(x21, y21, tank->x, tank->y, line_x1, line_y1))
            return 1;
        if (!o2 && onSeg(x21, y21, tank->x, tank->y, line_x2, line_y2))
            return 1;
        if (!o3 && onSeg(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y))
            return 1;
        if (!o4 && onSeg(line_x1, line_y1, line_x2, line_y2, x21, y21))
            return 1;

        o1 = orientation(x22, y22, tank->x, tank->y, line_x1, line_y1);
        o2 = orientation(x22, y22, tank->x, tank->y, line_x2, line_y2);
        o3 = orientation(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y);
        o4 = orientation(line_x1, line_y1, line_x2, line_y2, x22, y22);
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (!o1 && onSeg(x22, y22, tank->x, tank->y, line_x1, line_y1))
            return 1;
        if (!o2 && onSeg(x22, y22, tank->x, tank->y, line_x2, line_y2))
            return 1;
        if (!o3 && onSeg(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y))
            return 1;
        if (!o4 && onSeg(line_x1, line_y1, line_x2, line_y2, x22, y22))
            return 1;

        line_x1 = wall_scroller->x1 + ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y1 = wall_scroller->y1 + ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        line_x2 = wall_scroller->x2 + ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y2 = wall_scroller->y2 + ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        o1 = orientation(x21, y21, tank->x, tank->y, line_x1, line_y1);
        o2 = orientation(x21, y21, tank->x, tank->y, line_x2, line_y2);
        o3 = orientation(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y);
        o4 = orientation(line_x1, line_y1, line_x2, line_y2, x21, y21);
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (!o1 && onSeg(x21, y21, tank->x, tank->y, line_x1, line_y1))
            return 1;
        if (!o2 && onSeg(x21, y21, tank->x, tank->y, line_x2, line_y2))
            return 1;
        if (!o3 && onSeg(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y))
            return 1;
        if (!o4 && onSeg(line_x1, line_y1, line_x2, line_y2, x21, y21))
            return 1;

        o1 = orientation(x22, y22, tank->x, tank->y, line_x1, line_y1);
        o2 = orientation(x22, y22, tank->x, tank->y, line_x2, line_y2);
        o3 = orientation(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y);
        o4 = orientation(line_x1, line_y1, line_x2, line_y2, x22, y22);
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (!o1 && onSeg(x22, y22, tank->x, tank->y, line_x1, line_y1))
            return 1;
        if (!o2 && onSeg(x22, y22, tank->x, tank->y, line_x2, line_y2))
            return 1;
        if (!o3 && onSeg(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y))
            return 1;
        if (!o4 && onSeg(line_x1, line_y1, line_x2, line_y2, x22, y22))
            return 1;


        line_x1 = wall_scroller->x1 - ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y1 = wall_scroller->y1 - ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        line_x2 = wall_scroller->x2 - ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y2 = wall_scroller->y2 - ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        o1 = orientation(x21, y21, tank->x, tank->y, line_x1, line_y1);
        o2 = orientation(x21, y21, tank->x, tank->y, line_x2, line_y2);
        o3 = orientation(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y);
        o4 = orientation(line_x1, line_y1, line_x2, line_y2, x21, y21);
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (!o1 && onSeg(x21, y21, tank->x, tank->y, line_x1, line_y1))
            return 1;
        if (!o2 && onSeg(x21, y21, tank->x, tank->y, line_x2, line_y2))
            return 1;
        if (!o3 && onSeg(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y))
            return 1;
        if (!o4 && onSeg(line_x1, line_y1, line_x2, line_y2, x21, y21))
            return 1;

        o1 = orientation(x22, y22, tank->x, tank->y, line_x1, line_y1);
        o2 = orientation(x22, y22, tank->x, tank->y, line_x2, line_y2);
        o3 = orientation(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y);
        o4 = orientation(line_x1, line_y1, line_x2, line_y2, x22, y22);
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (!o1 && onSeg(x22, y22, tank->x, tank->y, line_x1, line_y1))
            return 1;
        if (!o2 && onSeg(x22, y22, tank->x, tank->y, line_x2, line_y2))
            return 1;
        if (!o3 && onSeg(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y))
            return 1;
        if (!o4 && onSeg(line_x1, line_y1, line_x2, line_y2, x22, y22))
            return 1;


        line_x1 = wall_scroller->x2 - ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y1 = wall_scroller->y2 - ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        line_x2 = wall_scroller->x2 + ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y2 = wall_scroller->y2 + ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        o1 = orientation(x21, y21, tank->x, tank->y, line_x1, line_y1);
        o2 = orientation(x21, y21, tank->x, tank->y, line_x2, line_y2);
        o3 = orientation(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y);
        o4 = orientation(line_x1, line_y1, line_x2, line_y2, x21, y21);
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (!o1 && onSeg(x21, y21, tank->x, tank->y, line_x1, line_y1))
            return 1;
        if (!o2 && onSeg(x21, y21, tank->x, tank->y, line_x2, line_y2))
            return 1;
        if (!o3 && onSeg(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y))
            return 1;
        if (!o4 && onSeg(line_x1, line_y1, line_x2, line_y2, x21, y21))
            return 1;

        o1 = orientation(x22, y22, tank->x, tank->y, line_x1, line_y1);
        o2 = orientation(x22, y22, tank->x, tank->y, line_x2, line_y2);
        o3 = orientation(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y);
        o4 = orientation(line_x1, line_y1, line_x2, line_y2, x22, y22);
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (o1 != o2 && o3 != o4) {
            return 1;
        }
        if (!o1 && onSeg(x22, y22, tank->x, tank->y, line_x1, line_y1))
            return 1;
        if (!o2 && onSeg(x22, y22, tank->x, tank->y, line_x2, line_y2))
            return 1;
        if (!o3 && onSeg(line_x1, line_y1, line_x2, line_y2, tank->x, tank->y))
            return 1;
        if (!o4 && onSeg(line_x1, line_y1, line_x2, line_y2, x22, y22))
            return 1;


        wall_scroller = wall_scroller->next;
    }
    return 0;
}

//////////////////////////////////////////recklessly changed line_coll and wall_coll x and y from int to double
int line_coll(double x, double y, int radius, double line_x1, double line_y1, double line_x2, double line_y2) {
    double line_cen_x = (line_x1 + line_x2) / 2;
    double line_cen_y = (line_y1 + line_y2) / 2;
    double line_length = fabs(line_x1 + line_y1 - line_x2 - line_y2);

    if (line_x1 == line_x2) {
        if (fabs(y - line_cen_y) < line_length / 2) {
            if (fabs(x - line_x1) < radius) {
                return 1;
            }
        } else if (sqrt((line_x1 - x) * (line_x1 - x) + (line_y1 - y) * (line_y1 - y)) < radius ||
                   sqrt((line_x2 - x) * (line_x2 - x) + (line_y2 - y) * (line_y2 - y)) < radius) {
            return 1;
        }
    } else {
        if (fabs(x - line_cen_x) < line_length / 2) {
            if (fabs(y - line_y1) < radius) {
                return 1;
            }
        } else if (sqrt((line_x1 - x) * (line_x1 - x) + (line_y1 - y) * (line_y1 - y)) < radius ||
                   sqrt((line_x2 - x) * (line_x2 - x) + (line_y2 - y) * (line_y2 - y)) < radius) {
            return 1;
        }
    }
    return 0;
}

int wall_coll(double x, double y, int radius) {
    Wall *wall_scroller = walls;
    while (wall_scroller) {
        double line_x1, line_y1, line_x2, line_y2;
        line_x1 = wall_scroller->x1 - ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y1 = wall_scroller->y1 - ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        line_x2 = wall_scroller->x1 + ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y2 = wall_scroller->y1 + ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        if (line_coll(x, y, radius, line_x1, line_y1, line_x2, line_y2))
            return 1;

        line_x1 = wall_scroller->x1 + ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y1 = wall_scroller->y1 + ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        line_x2 = wall_scroller->x2 + ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y2 = wall_scroller->y2 + ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        if (line_coll(x, y, radius, line_x1, line_y1, line_x2, line_y2))
            return 1;

        line_x1 = wall_scroller->x1 - ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y1 = wall_scroller->y1 - ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        line_x2 = wall_scroller->x2 - ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y2 = wall_scroller->y2 - ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        if (line_coll(x, y, radius, line_x1, line_y1, line_x2, line_y2))
            return 1;

        line_x1 = wall_scroller->x2 - ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y1 = wall_scroller->y2 - ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        line_x2 = wall_scroller->x2 + ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
        line_y2 = wall_scroller->y2 + ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
        if (line_coll(x, y, radius, line_x1, line_y1, line_x2, line_y2))
            return 1;

        wall_scroller = wall_scroller->next;
    }
    return 0;
}










char reflecterLineColl(Bullet *bulletAdress, double line_x1, double line_y1, double line_x2, double line_y2) {
    if ((line_x1 == line_x2 && bulletAdress->y <= (line_y1 > line_y2 ? line_y1 : line_y2) &&
         bulletAdress->y >= (line_y1 > line_y2 ? line_y2 : line_y1)) ||
        (line_y1 == line_y2 && bulletAdress->x <= (line_x1 > line_x2 ? line_x1 : line_x2) &&
         bulletAdress->x >= (line_x1 > line_x2 ? line_x2 : line_x1))) {
        if (fabs(line_x1 == line_x2 ? line_x1 - bulletAdress->x : line_y1 - bulletAdress->y) <
            bulletAdress->radius) {
            if (line_x1 == line_x2) {
                return 'v';
            } else {
                return 'h';
            }
        }
    } else if (sqrt((line_x1 - bulletAdress->x) * (line_x1 - bulletAdress->x) +
                    (line_y1 - bulletAdress->y) * (line_y1 - bulletAdress->y)) < bulletAdress->radius) {
        return '1';
    } else if (sqrt((line_x2 - bulletAdress->x) * (line_x2 - bulletAdress->x) +
                    (line_y2 - bulletAdress->y) * (line_y2 - bulletAdress->y)) < bulletAdress->radius) {
        return '2';
    }
    return 0;
}

void
aRepetativeSwitch(Bullet *bulletAdress, double line_x1, double line_y1, double line_x2, double line_y2, int *history) {
    switch (reflecterLineColl(bulletAdress, line_x1, line_y1, line_x2, line_y2)) {
        case 'h':
            if(*history!=1) {
                bulletAdress->angel = -bulletAdress->angel;
                *history = *history==2?3:1;
            }
            break;
        case 'v':
            if(*history!=2) {
                bulletAdress->angel = 180 - bulletAdress->angel;
                *history = *history==1?3:2;
            }
            break;
        case '1':
            if (!*history)
                *history = 21;
            break;
        case '2':
            if (!*history)
                *history = 22;
            break;
    }
}

void reflectBullet(Bullet *bulletAdress) {
    for (;bulletAdress;bulletAdress = bulletAdress->next) {
        if(bulletAdress->type==5 && wall_coll(bulletAdress->x,bulletAdress->y,bulletAdress->radius)){
            bulletAdress->birthday-=bullet_lifetime;
            continue;
        }

        Wall *wall_scroller = walls;
        int history = 0;
        double tipAngle=-3123;   //////////////why 45???!!!
        while (wall_scroller) {
            double line_x1, line_y1, line_x2, line_y2;

            line_x1 = wall_scroller->x1 - ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
            line_y1 = wall_scroller->y1 - ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
            line_x2 = wall_scroller->x1 + ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
            line_y2 = wall_scroller->y1 + ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
            aRepetativeSwitch(bulletAdress, line_x1, line_y1, line_x2, line_y2, &history);
            if (history == 3) {
                break;
            }
            if (history == 21) {
                history = 5;
                double boxCenX = (double) (wall_scroller->x1 + wall_scroller->x2) / 2;
                double boxCenY = (double) (wall_scroller->y1 + wall_scroller->y2) / 2;
                if (line_x1 > boxCenX && line_y1 > boxCenY) {
                    tipAngle = 43;
                } else if (line_x1 > boxCenX && line_y1 < boxCenY) {
                    tipAngle = -43;
                } else if (line_x1 < boxCenX && line_y1 > boxCenY) {
                    tipAngle = 133;
                } else if (line_x1 < boxCenX && line_y1 < boxCenY) {
                    tipAngle = -133;
                }
            } else if (history == 22) {
                history = 5;
                double boxCenX = (double) (wall_scroller->x1 + wall_scroller->x2) / 2;
                double boxCenY = (double) (wall_scroller->y1 + wall_scroller->y2) / 2;
                if (line_x2 > boxCenX && line_y2 > boxCenY) {
                    tipAngle = 43;
                } else if (line_x2 > boxCenX && line_y2 < boxCenY) {
                    tipAngle = -43;
                } else if (line_x2 < boxCenX && line_y2 > boxCenY) {
                    tipAngle = 133;
                } else if (line_x2 < boxCenX && line_y2 < boxCenY) {
                    tipAngle = -133;
                }
            }

            line_x1 = wall_scroller->x1 + ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
            line_y1 = wall_scroller->y1 + ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
            line_x2 = wall_scroller->x2 + ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
            line_y2 = wall_scroller->y2 + ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
            aRepetativeSwitch(bulletAdress, line_x1, line_y1, line_x2, line_y2, &history);
            if (history == 3) {
                break;
            }
            if (history == 21) {
                history = 5;
                double boxCenX = (double) (wall_scroller->x1 + wall_scroller->x2) / 2;
                double boxCenY = (double) (wall_scroller->y1 + wall_scroller->y2) / 2;
                if (line_x1 > boxCenX && line_y1 > boxCenY) {
                    tipAngle = 43;
                } else if (line_x1 > boxCenX && line_y1 < boxCenY) {
                    tipAngle = -43;
                } else if (line_x1 < boxCenX && line_y1 > boxCenY) {
                    tipAngle = 133;
                } else if (line_x1 < boxCenX && line_y1 < boxCenY) {
                    tipAngle = -133;
                }
            } else if (history == 22) {
                history = 5;
                double boxCenX = (double) (wall_scroller->x1 + wall_scroller->x2) / 2;
                double boxCenY = (double) (wall_scroller->y1 + wall_scroller->y2) / 2;
                if (line_x2 > boxCenX && line_y2 > boxCenY) {
                    tipAngle = 43;
                } else if (line_x2 > boxCenX && line_y2 < boxCenY) {
                    tipAngle = -43;
                } else if (line_x2 < boxCenX && line_y2 > boxCenY) {
                    tipAngle = 133;
                } else if (line_x2 < boxCenX && line_y2 < boxCenY) {
                    tipAngle = -133;
                }
            }

            line_x1 = wall_scroller->x1 - ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
            line_y1 = wall_scroller->y1 - ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
            line_x2 = wall_scroller->x2 - ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
            line_y2 = wall_scroller->y2 - ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
            aRepetativeSwitch(bulletAdress, line_x1, line_y1, line_x2, line_y2, &history);
            if (history == 3) {
                break;
            }
            if (history == 21) {
                history = 5;
                double boxCenX = (double) (wall_scroller->x1 + wall_scroller->x2) / 2;
                double boxCenY = (double) (wall_scroller->y1 + wall_scroller->y2) / 2;
                if (line_x1 > boxCenX && line_y1 > boxCenY) {
                    tipAngle = 43;
                } else if (line_x1 > boxCenX && line_y1 < boxCenY) {
                    tipAngle = -43;
                } else if (line_x1 < boxCenX && line_y1 > boxCenY) {
                    tipAngle = 133;
                } else if (line_x1 < boxCenX && line_y1 < boxCenY) {
                    tipAngle = -133;
                }
            } else if (history == 22) {
                history = 5;
                double boxCenX = (double) (wall_scroller->x1 + wall_scroller->x2) / 2;
                double boxCenY = (double) (wall_scroller->y1 + wall_scroller->y2) / 2;
                if (line_x2 > boxCenX && line_y2 > boxCenY) {
                    tipAngle = 43;
                } else if (line_x2 > boxCenX && line_y2 < boxCenY) {
                    tipAngle = -43;
                } else if (line_x2 < boxCenX && line_y2 > boxCenY) {
                    tipAngle = 133;
                } else if (line_x2 < boxCenX && line_y2 < boxCenY) {
                    tipAngle = -133;
                }
            }

            line_x1 = wall_scroller->x2 - ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
            line_y1 = wall_scroller->y2 - ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
            line_x2 = wall_scroller->x2 + ((wall_scroller->x2 == wall_scroller->x1) ? (double) wall_width / 2 : 0);
            line_y2 = wall_scroller->y2 + ((wall_scroller->x2 == wall_scroller->x1) ? 0 : (double) wall_width / 2);
            aRepetativeSwitch(bulletAdress, line_x1, line_y1, line_x2, line_y2, &history);
            if (history == 3) {
                break;
            }
            if (history == 21) {
                history = 5;
                double boxCenX = (double) (wall_scroller->x1 + wall_scroller->x2) / 2;
                double boxCenY = (double) (wall_scroller->y1 + wall_scroller->y2) / 2;
                if (line_x1 > boxCenX && line_y1 > boxCenY) {
                    tipAngle = 43;
                } else if (line_x1 > boxCenX && line_y1 < boxCenY) {
                    tipAngle = -43;
                } else if (line_x1 < boxCenX && line_y1 > boxCenY) {
                    tipAngle = 133;
                } else if (line_x1 < boxCenX && line_y1 < boxCenY) {
                    tipAngle = -133;
                }
            } else if (history == 22) {
                history = 5;
                double boxCenX = (double) (wall_scroller->x1 + wall_scroller->x2) / 2;
                double boxCenY = (double) (wall_scroller->y1 + wall_scroller->y2) / 2;
                if (line_x2 > boxCenX && line_y2 > boxCenY) {
                    tipAngle = 43;
                } else if (line_x2 > boxCenX && line_y2 < boxCenY) {
                    tipAngle = -43;
                } else if (line_x2 < boxCenX && line_y2 > boxCenY) {
                    tipAngle = 133;
                } else if (line_x2 < boxCenX && line_y2 < boxCenY) {
                    tipAngle = -133;
                }
            }

            wall_scroller = wall_scroller->next;
        }
        if (history == 5) {
            bulletAdress->angel = tipAngle;
        }

        bulletAdress->angel = (long long) bulletAdress->angel % 360;
    }
}