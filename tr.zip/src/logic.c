#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include "struct.h"
#include "coll.h"
#include <math.h>
#include "powerups.h"
#include "singers.h"

double degtorad(double deg) {
    return deg * M_PI / 180;
}

double radtodeg(double rad) {
    return rad * 180 / M_PI;
}

void move_tank(char direction, Tank *tank) {
    double reducedXMoveSpeed = cos(degtorad(tank->angel)) * tank_move_speed, reducedYMoveSpeed =
            sin(degtorad(tank->angel)) * tank_move_speed;
    int frictionPresense = 0;

    switch (direction) {
        case 'u':
            while ((wall_coll(tank->x + reducedXMoveSpeed, tank->y, tankradius)) &&
                   fabs(reducedXMoveSpeed)) {
                if (reducedXMoveSpeed > 0)
                    reducedXMoveSpeed -= 1;
                else
                    reducedXMoveSpeed += 1;

                if (fabs(reducedXMoveSpeed) <= 1) {
                    reducedXMoveSpeed = 0;
                    frictionPresense = 1;
                }
            }
            while ((wall_coll(tank->x, tank->y + reducedYMoveSpeed, tankradius)) &&
                   fabs(reducedYMoveSpeed)) {
                if (reducedYMoveSpeed > 0)
                    reducedYMoveSpeed -= 1;
                else
                    reducedYMoveSpeed += 1;

                if (fabs(reducedYMoveSpeed) <= 1) {
                    reducedYMoveSpeed = 0;
                    frictionPresense = 1;
                }
            }

            if (frictionPresense) {
                reducedXMoveSpeed *= frictionConstant;
                reducedYMoveSpeed *= frictionConstant;
            }

            tank->x += reducedXMoveSpeed;
            tank->y += reducedYMoveSpeed;

            int howMuchPlus = 0, howMuchMinus = 0;
            while (pipeColl(tank)) {
                tank->angel += 1;
                howMuchPlus++;
            }
            tank->angel -= howMuchPlus;
            while (pipeColl(tank)) {
                tank->angel -= 1;
                howMuchMinus++;
            }
            tank->angel += howMuchMinus;
            if (howMuchMinus < howMuchPlus) {
                tank->angel -= howMuchMinus;
            } else if (howMuchMinus > howMuchPlus) {
                tank->angel += howMuchPlus;
            } else {
                while (pipeColl(tank)) {
                    move_tank('d', tank);
                }
            }

            break;
        case 'd':
            while (wall_coll(tank->x - reducedXMoveSpeed, tank->y, tankradius) && fabs(reducedXMoveSpeed)) {
                if (reducedXMoveSpeed > 0)
                    reducedXMoveSpeed -= 1;
                else
                    reducedXMoveSpeed += 1;

                if (fabs(reducedXMoveSpeed) <= 1) {
                    reducedXMoveSpeed = 0;
                    frictionPresense = 1;
                }
            }
            while (wall_coll(tank->x, tank->y - reducedYMoveSpeed, tankradius) && fabs(reducedYMoveSpeed)) {
                if (reducedYMoveSpeed > 0)
                    reducedYMoveSpeed -= 1;
                else
                    reducedYMoveSpeed += 1;

                if (fabs(reducedYMoveSpeed) <= 1) {
                    reducedYMoveSpeed = 0;
                    frictionPresense = 1;
                }
            }

            if (frictionPresense) {
                reducedXMoveSpeed *= frictionConstant;
                reducedYMoveSpeed *= frictionConstant;
            }

            tank->x -= reducedXMoveSpeed;
            tank->y -= reducedYMoveSpeed;

            while (pipeColl(tank)) {
                move_tank('d', tank);
            }

            break;
        case 'r':
            tank->angel += tank_rotate_speed;

            if (tank->angel < 0)
                tank->angel += 360;
            if (tank->angel > 360)
                tank->angel -= 360;

            while (pipeColl(tank)) {
                move_tank('d', tank);
            }
            break;
        case 'l':
            tank->angel -= tank_rotate_speed;

            if (tank->angel < 0)
                tank->angel += 360;
            if (tank->angel > 360)
                tank->angel -= 360;

            while (pipeColl(tank)) {
                move_tank('d', tank);
            }
            break;
    }
}

void kill_old_bullets(Bullet **bullet_adress_adress) {
    while (*bullet_adress_adress) {
        int deleted = 0;
        if (SDL_GetTicks() - (*bullet_adress_adress)->birthday > bullet_lifetime) {

            if ((*bullet_adress_adress)->type == 7 && !(*bullet_adress_adress)->mineDet) {
                bullet_adress_adress = &(*bullet_adress_adress)->next;
                continue;
            }

            if ((*bullet_adress_adress)->type == 4) {
                detonateGren(&(*bullet_adress_adress)->next, *bullet_adress_adress);
                (*bullet_adress_adress)->father->powerUP = 0;
            }

            if ((*bullet_adress_adress)->type == 0)
                (*bullet_adress_adress)->father->usedbullts--;

            Bullet *temp = (*bullet_adress_adress)->next;
            free(*bullet_adress_adress);
            *bullet_adress_adress = temp;

            deleted = 1;
        }
        if (!deleted) {
            bullet_adress_adress = &(*bullet_adress_adress)->next;
        }
    }
}

void move_bullets(Bullet *bullet_adress) {
    while (bullet_adress) {
        bullet_adress->x += cos(degtorad(bullet_adress->angel)) * bullet_adress->speed;
        bullet_adress->y += sin(degtorad(bullet_adress->angel)) * bullet_adress->speed;

        bullet_adress = bullet_adress->next;
    }
}

void manage_bullets(Bullet **first_bullet_adress_adress) {
    kill_old_bullets(first_bullet_adress_adress);
    move_bullets(*first_bullet_adress_adress);
    reflectBullet(*first_bullet_adress_adress);
}

int killWithBullet(Tank *tanks, Bullet *bulletP) {
    int killedSO = 0;
    for (; bulletP; bulletP = bulletP->next) {

        int Onmine = 0;

        for (int i = 0; i < number_of_players; i++) {
            if (!tanks[i].exists)
                continue;

            if (sqrt((bulletP->x - tanks[i].x) * (bulletP->x - tanks[i].x) +
                     (bulletP->y - tanks[i].y) * (bulletP->y - tanks[i].y)) < tankradius + bulletP->radius) {
                if (bulletP->type != 1) {

                    if ((bulletP->type == 7 &&
                         (int) SDL_GetTicks() - bulletP->mineDetect < mine_detonation_delay) ||
                        (bulletP->type == 7 && (int) SDL_GetTicks() - bulletP->birthday < mine_activation_delay)) {
                        if ((int) SDL_GetTicks() - bulletP->birthday > mine_activation_delay) {
                            playEff(6);
                        }

                        Onmine = 1;
                        continue;
                    }

                    if (bulletP->type == 2 && tanks + i == bulletP->father && bulletP->isTipOfLaser != 1) {
                        continue;
                    }

                    if (bulletP->type == 3 && ( (int)SDL_GetTicks()-bulletP->birthday>bullet_lifetime-ray_frames_after_finish_that_i_dont_know_why_exitst*1000/fps || bulletP->father->powerUP==22) ) {
                        continue;
                    } else if(bulletP->father->powerUP==2){
                        bulletP->father->powerUP = 22;
                    }

                    tanks[i].exists--;
                    if (tanks[i].exists == 0) {
                        playEff(13);

                        tanks[i].powerUP = 0;
                    } else {
                        playEff(4);
                    }
                    killedSO = 1;
                    if (bulletP->type == 7)
                        bulletP->mineDet = 1;
                }

                if (bulletP->type != 3)
                    bulletP->birthday -= bullet_lifetime;
            }
        }
        if (bulletP->type == 7 && Onmine == 0) {
            bulletP->mineDetect = SDL_GetTicks();
        }
    }
    return killedSO;
}

int isThereAWinner(Tank *tanks) {
    int numOfAlives = 0;
    for (int i = 0; i < number_of_players; i++) {
        if (tanks[i].exists)
            numOfAlives++;
        if (numOfAlives > 1)
            return 0;
    }
    if (numOfAlives == 1)
        return 1;
    if (numOfAlives == 0)
        return 2;
}

int checkWhatIsGoingOn(Tank *tanks, Bullet *bulletP) {
    killWithBullet(tanks, bulletP);
    return isThereAWinner(tanks);
}

void addScore(Tank *tanks) {
    for (int i = 0; i < number_of_players; i++) {
        if (tanks[i].exists) {
            tanks[i].score++;
            return;
        }
    }
}

int checkScoreLimit(Tank *tanks, int scorelimit) {
    for (int i = 0; i < number_of_players; i++) {
        if (scorelimit % 10000 == 1231 || scorelimit % 10000 == 1234 || scorelimit % 10000 == 1235) {
            if (scorelimit / 10000 && tanks[i].score == scorelimit / 10000)
                return i;
        } else if (tanks[i].score == scorelimit)
            return i;
    }
    return -1;
}

void garbageCollector(Bullet **bullet) {
    while (*bullet) {
        Bullet *nextbu = (*bullet)->next;
        free(*bullet);
        *bullet = nextbu;
    }

    while (walls) {
        Wall *nextbu = walls->next;
        free(walls);
        walls = nextbu;
    }

    while (puHead) {
        Powerup *nextbu = puHead->next;
        free(puHead);
        puHead = nextbu;
    }
}

void fixBirthdays(Bullet *bullet, int timeElapsed) {
    for (; bullet; bullet = bullet->next) {
        bullet->birthday += timeElapsed;
    }
}

