you need to install nfd.h from here: https://github.com/mlabbe/nativefiledialog
and install sdl2_mixer
and have sound files on my computer

to run this project.
