#ifndef coll_h
#define coll_h

int wall_coll(double x, double y, int radius);

void reflectBullet(Bullet *);

int pipeColl(Tank*);

#endif