#include <stdio.h>
#include <SDL_scancode.h>
#include "struct.h"
#include <SDL_mixer.h>

const int winMaxWidth = 1600, winMaxHeight = 900, window_x = 20, window_y = 20, scoreBoardHeight = 120;
int windowWidth, windowHeight;
const int number_of_players = 2, winner_delay = 4000, screenshotTime = 333,winnerScreenTime=3000;
int  scoreLimit = -1;
const int tankradius = 20, tank_pipe_length = 32, tank_pipe_span = 7, tank_pipe_howmany_lines = 30, tank_move_speed = 4, tank_rotate_speed = 4, max_bullets = 5;
const int fps = 70;
const int bullet_radius = 6, bullet_move_speed = 5, bullet_lifetime = 10000;
const int number_of_maps = 0, wall_width = 16, destructionChance = 33;
Wall *walls = NULL;
Powerup *puHead=NULL;
const double frictionConstant = .4;
const Color pallet[] = {{.r=0, .g=153, .b=51},
                        {.r=255, .g=80, .b=80},
                        {.r=0, .g=153, .b=255}};
const layout defaultKeyLayout[] = {{.shoot=SDL_SCANCODE_M, .right=SDL_SCANCODE_RIGHT, .left=SDL_SCANCODE_LEFT, .up=SDL_SCANCODE_UP, .down=SDL_SCANCODE_DOWN},
                                   {.shoot=SDL_SCANCODE_1, .up=SDL_SCANCODE_W, .down=SDL_SCANCODE_S, .right=SDL_SCANCODE_D, .left=SDL_SCANCODE_A}};


const int laser_frames = 20, ray_radius = 12, ray_time = 1000, ray_delay = 500, ray_frames_after_finish_that_i_dont_know_why_exitst = 6, frag_number = 40,laser_bullet_radius = 3, gren_bullet_radius = 8, frag_radius = 4, shotgun_radius = 4, frag_move_speed = 8, shotgun_move_speed = 6,shotgun_lifetime=1500,shotgun_number=10,shotgun_spread=3,mine_activation_delay=1000,mine_radius=20,mine_detonation_delay=300,mine_charge=3;
const double ray_curvature = .2;
const int PUradius=15,laser_chance=2,ray_chance=1,gren_chance=3,shotgun_chance=3,mine_chance=3,health_chance=2,random_time_low=10000,random_time_high=15000;
Mix_Chunk *buttonch,*buttonse,*grenex,*health,*hurt,*laser,*minedet,*mineput,*pu,*rayself,*raydelay,*shoots,*shotguns,*tankex,*winnerbell,*newpu;
Music startMusic,menuMusic;
int mute=0;