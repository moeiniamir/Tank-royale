//
// Created by amir on 1/28/19.
//

#ifndef TR_FILETOHANDLEFILES_H
#define TR_FILETOHANDLEFILES_H

#include "struct.h"

void save(Tank *tanks,Bullet *bulletHead);

int load(Tank *tanks,Bullet **bulletHead);

#endif //TR_FILETOHANDLEFILES_H
