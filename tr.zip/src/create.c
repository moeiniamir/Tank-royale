#include "struct.h"
#include <time.h>
#include "coll.h"
#include <stdlib.h>
#include <math.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include "logic.h"
#include "singers.h"


Tank *create_tank(void) {
    Tank *ptr = malloc(sizeof(Tank) * number_of_players);
    for (int i = 0; i < number_of_players; i++) {
        ptr[i].score = 0;
        ptr[i].color.r = pallet[i].r;
        ptr[i].color.g = pallet[i].g;
        ptr[i].color.b = pallet[i].b;
        ptr[i].lo = defaultKeyLayout[i];
    }
    return ptr;
}

void initTanks(Tank ptr[], int width, int height) {
    for (int i = 0; i < number_of_players; i++) {
        ptr[i].x = rand() % width;
        ptr[i].y = rand() % height;
        if (wall_coll(ptr[i].x, ptr[i].y, tankradius)) {
            i--;
            continue;
        }
        ptr[i].angel = rand() % 360;
        ptr[i].usedbullts = 0;
        ptr[i].exists = 1;
        ptr[i].shootPressed = 0;
        ptr[i].mineCharge=mine_charge;
        ptr[i].rayStartTime = -(ray_delay + ray_delay);
        switch (scoreLimit % 10000) {
            case 1231:
                ptr[i].powerUP = 1;
                break;
            case 1234:
                ptr[i].powerUP = 4;
                break;
            case 1235:
                ptr[i].powerUP = 5;
                break;
            default:
                ptr[i].powerUP = 0;
                break;
        }
    }

}

void create_bullet(Tank *tank, Bullet **first_bullet_p_p, int type) {
    if (tank->usedbullts < max_bullets || type != 0) {
        Bullet *new = malloc(sizeof(Bullet));
        new->next = *first_bullet_p_p;
        *first_bullet_p_p = new;

        new->father = tank;
        new->angel = tank->angel;
        new->type = type;

        switch (type) {
            case 0:
                playEff(11);

                new->radius = bullet_radius;
                new->birthday = SDL_GetTicks();
                new->color.r = 0;
                new->color.g = 0;
                new->color.b = 0;
                new->speed = bullet_move_speed;
                tank->usedbullts++;
                new->x = tank->x + cos(degtorad(tank->angel)) * (new->radius + tankradius);
                new->y = tank->y + sin(degtorad(tank->angel)) * (new->radius + tankradius);
                break;
            case 1:
                new->radius = laser_bullet_radius;
                new->birthday = SDL_GetTicks() - bullet_lifetime;
                new->color.r = 100;
                new->color.g = 100;
                new->color.b = 100;
                new->speed = bullet_move_speed;
                new->x = tank->x + cos(degtorad(tank->angel)) * (new->radius + tankradius);
                new->y = tank->y + sin(degtorad(tank->angel)) * (new->radius + tankradius);
                break;
            case 2:
                new->radius = laser_bullet_radius;
                new->birthday = SDL_GetTicks() - bullet_lifetime + laser_frames * 1000 / fps;
                new->color.r = 255;
                new->color.g = 80;
                new->color.b = 80;
                new->speed = bullet_move_speed;
                new->isTipOfLaser = 0;
                new->x = tank->x + cos(degtorad(tank->angel)) * (new->radius + tankradius);
                new->y = tank->y + sin(degtorad(tank->angel)) * (new->radius + tankradius);
                break;
            case 3:
                new->radius = ray_radius;
                new->birthday = SDL_GetTicks() - bullet_lifetime + ray_time;
                new->color.r = 255;
                new->color.g = 80;
                new->color.b = 80;
                new->speed = bullet_move_speed;
                new->x = tank->x + cos(degtorad(tank->angel)) * (new->radius + tankradius);
                new->y = tank->y + sin(degtorad(tank->angel)) * (new->radius + tankradius);
                break;
            case 4:
                new->radius = gren_bullet_radius;
                new->birthday = SDL_GetTicks();
                new->color.r = 0;
                new->color.g = 0;
                new->color.b = 0;
                new->speed = bullet_move_speed;
                new->x = tank->x + cos(degtorad(tank->angel)) * (new->radius + tankradius);
                new->y = tank->y + sin(degtorad(tank->angel)) * (new->radius + tankradius);
                break;
            case 5:
                new->radius = frag_radius;
                new->birthday = SDL_GetTicks();
                new->color.r = 0;
                new->color.g = 0;
                new->color.b = 0;
                new->speed = frag_move_speed;
                new->x = tank->x + cos(degtorad(tank->angel)) * (new->radius + tankradius);
                new->y = tank->y + sin(degtorad(tank->angel)) * (new->radius + tankradius);
                break;
            case 6:
                new->radius = shotgun_radius;
                new->birthday = SDL_GetTicks() - bullet_lifetime + shotgun_lifetime;
                new->color.r = 0;
                new->color.g = 0;
                new->color.b = 0;
                new->speed = shotgun_move_speed;
                new->x = tank->x + cos(degtorad(tank->angel)) * (new->radius + tankradius);
                new->y = tank->y + sin(degtorad(tank->angel)) * (new->radius + tankradius);
                break;
            case 7:
                new->radius = mine_radius;
                new->birthday = SDL_GetTicks();
                new->color.r = 255;
                new->color.g = 153;
                new->color.b = 0;
                new->speed = 0;
                new->mineDet = 0;
                new->mineDetect = SDL_GetTicks() + mine_activation_delay;
                new->x = tank->x;                     //////////////////////over write of x and y
                new->y = tank->y;
                break;
        }
    }
}