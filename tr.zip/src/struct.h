#ifndef struct_h
#define struct_h

#include <SDL_mixer.h>

typedef struct {
    int r, g, b;
} Color;

typedef struct {
    int shoot;
    int right;
    int left;
    int up;
    int down;
} layout;

typedef struct {
    double x, y;
    double angel;
    int usedbullts;
    int exists;
    int shootPressed;
    int score;
    int powerUP;  //0: nothing      1: laser    2: ray      3: gren     33: grenC    4: shotgun      5: mine

    int mineCharge;
    int rayStartTime;
    Color color;
    layout lo;
} Tank;

typedef struct Bullet {
    double x, y;
    double angel;
    int birthday;
    Tank *father;
    struct Bullet *next;
    int radius;
    int speed;
    int type;  // 0: normal     1: laser trail      2: laser    3: ray      4: gren     5: frag     6: shotgun      7:mine
    int isTipOfLaser;
    int mineDetect;
    int mineDet;
    Color color;
} Bullet;

typedef struct Powerup{
    double x,y;
    int type;   // 0: health    1: laser    2: ray      3: gren     4: shotgun      5: mine
    int eaten;
    struct Powerup *next;
}Powerup;

typedef struct Wall {
    int x1, y1, x2, y2;
    struct Wall *next;
} Wall;

typedef struct {
    Mix_Chunk *music;
    int channel;
}Music;

extern const int winMaxWidth, winMaxHeight, window_x, window_y, scoreBoardHeight;
extern const int number_of_players, winner_delay, screenshotTime,winnerScreenTime;
extern int scoreLimit;
extern const int tankradius, tank_pipe_length, tank_pipe_span, tank_pipe_howmany_lines, tank_move_speed, tank_rotate_speed, max_bullets;
extern const int fps;
extern const int bullet_radius, bullet_move_speed, bullet_lifetime;
extern const int number_of_maps, wall_width, destructionChance;
extern const double frictionConstant;
extern const Color pallet[];
extern const layout defaultKeyLayout[];
extern int windowWidth, windowHeight;
extern Wall *walls;
extern Powerup *puHead;
extern const int laser_frames, ray_radius, ray_time, ray_delay, ray_frames_after_finish_that_i_dont_know_why_exitst, frag_number,
        laser_bullet_radius, gren_bullet_radius, frag_radius, shotgun_radius, frag_move_speed, shotgun_move_speed,
        shotgun_lifetime,shotgun_number,shotgun_spread,mine_activation_delay,mine_radius,mine_detonation_delay;
extern const double ray_curvature;
extern const int PUradius,laser_chance,ray_chance,gren_chance,shotgun_chance,mine_chance,health_chance,random_time_low,random_time_high,mine_charge;
extern Mix_Chunk *buttonch,*buttonse,*grenex,*health,*hurt,*laser,*minedet,*mineput,*pu,*rayself,*raydelay,*shoots,*shotguns,*tankex,*winnerbell,*newpu;
extern Music startMusic,menuMusic;
extern int mute;
#endif
