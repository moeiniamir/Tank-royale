#ifndef TR_POWERUPS_H
#define TR_POWERUPS_H

#include "struct.h"

void powerUpsBG(Bullet **firstBullet, Tank *tanks);

void shoot(Tank *tanks,int which,Bullet **firstBullet);

void detonateGren(Bullet **firstBullet,Bullet *gren);

#endif //TR_POWERUPS_H
