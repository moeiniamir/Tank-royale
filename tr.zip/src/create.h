#ifndef create_h
#define create_h

#include "struct.h"

Tank *create_tank();

void initTanks(Tank ptr[],int width,int height);

void create_bullet(Tank *, Bullet **,int type);

#endif