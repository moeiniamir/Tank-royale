#include "struct.h"
#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <time.h>
#include "logic.h"

void dfs(int **grid, int x, int y, int columns, int rows) {
    int randomDestruction = !(rand() % (100 / destructionChance));
    if (randomDestruction) {
        int randomMissileDirection = rand() % 2;
        grid[x][y] |= 1 << randomMissileDirection;
    }
    while ((x - 1 >= 0 && !(grid[x - 1][y] & 1 << 2)) || (y - 1 >= 0 && !(grid[x][y - 1] & 1 << 2)) ||
           (x + 1 < columns && !(grid[x + 1][y] & 1 << 2)) ||
           (y + 1 < rows && !(grid[x][y + 1] & 1 << 2))) {
        int which = rand() % 4;
        switch (which) {
            case 0:
                if (x + 1 < columns && !(grid[x + 1][y] & 1 << 2)) {
                    grid[x + 1][y] |= 1 << 2;
                    grid[x][y] |= 1 << 0;
                    dfs(grid, x + 1, y, columns, rows);
                }
                break;
            case 1:
                if (y + 1 < rows && !(grid[x][y + 1] & 1 << 2)) {
                    grid[x][y + 1] |= 1 << 2;
                    grid[x][y] |= 1 << 1;
                    dfs(grid, x, y + 1, columns, rows);
                }
                break;
            case 2:
                if (x - 1 >= 0 && !(grid[x - 1][y] & 1 << 2)) {
                    grid[x - 1][y] |= 1 << 2;
                    grid[x - 1][y] |= 1 << 0;
                    dfs(grid, x - 1, y, columns, rows);
                }
                break;
            case 3:
                if (y - 1 >= 0 && !(grid[x][y - 1] & 1 << 2)) {
                    grid[x][y - 1] |= 1 << 2;
                    grid[x][y - 1] |= 1 << 1;
                    dfs(grid, x, y - 1, columns, rows);
                }
                break;
        }
    }
}

void generate_walls(void) {
    int wallsMarginInRadius = rand() % 5 + 5;
    int walls_margin = (tankradius * wallsMarginInRadius);
    int windoWidthLocal=0, windowHeightLocal=0;
    for (int i = 1; i * walls_margin < winMaxWidth; i++) windoWidthLocal = i * walls_margin;
    for (int i = 1; i * walls_margin < winMaxHeight; i++) windowHeightLocal = i * walls_margin;

    int columns = windoWidthLocal / walls_margin;
    int rows = windowHeightLocal / walls_margin;
    int **grid = malloc(sizeof(int *) * columns);
    for (int i = 0; i < columns; i++) {
        grid[i] = malloc(sizeof(int) * rows);
    }
    for (int i1 = 0; i1 < columns; i1++)
        for (int i2 = 0; i2 < rows; i2++)
            grid[i1][i2] = 0;

    dfs(grid, rand() % columns, rand() % rows, columns, rows);

    FILE *map = fopen("rgm.txt", "w+");

    fprintf(map, "%d %d\n", windoWidthLocal, windowHeightLocal);

    int numberOfWalls = 4;
    for (int i1 = 0; i1 < columns; i1++) {
        for (int i2 = 0; i2 < rows; i2++) {
            numberOfWalls += !(grid[i1][i2] & 1 << 0) + !(grid[i1][i2] & 1 << 1);
        }
    }
    fprintf(map, "%d\n", numberOfWalls);

    fprintf(map, "%d %d %d %d\n%d %d %d %d\n%d %d %d %d\n%d %d %d %d\n", 0, 0, windoWidthLocal, 0, 0, 0, 0,
            windowHeightLocal,
            0, windowHeightLocal, windoWidthLocal, windowHeightLocal, windoWidthLocal, 0, windoWidthLocal,
            windowHeightLocal);
    for (int i1 = 0; i1 < columns; i1++) {
        for (int i2 = 0; i2 < rows; i2++) {
            if (!(grid[i1][i2] & 1 << 0)) {
                fprintf(map, "%d %d %d %d\n", (i1 + 1) * walls_margin, i2 * walls_margin, (i1 + 1) * walls_margin,
                        (i2 + 1) * walls_margin);
            }
            if (!(grid[i1][i2] & 1 << 1)) {
                fprintf(map, "%d %d %d %d\n", i1 * walls_margin - wall_width / 2, (i2 + 1) * walls_margin,
                        (i1 + 1) * walls_margin + wall_width / 2-1,
                        (i2 + 1) * walls_margin);          //////////////////////minus one in "wall_width/2". but why??????!
            }
        }
    }

    for (int i = 0; i < columns; i++) {
        free(grid[i]);
    }
    free(grid);
    fclose(map);
}

void readFromFile(void) {
    FILE *map = NULL;

    if (number_of_maps && rand() % 2) {
        int which_map = rand() % number_of_maps + 1;
        char map_name[100] = {0};
        sprintf(map_name, "map%d.txt", which_map);
        map = fopen(map_name, "r");
    } else {
        generate_walls();
        map = fopen("rgm.txt", "r");
    }

    fscanf(map, "%d%d", &windowWidth, &windowHeight);

    int number_of_walls = 0;
    fscanf(map, "%d", &number_of_walls);

    Wall **roller = &walls;
    for (int i = 0; i < number_of_walls; i++) {
        *roller = malloc(sizeof(Wall));
        int in;
        fscanf(map, "%d", &in);
        (*roller)->x1 = in;
        fscanf(map, "%d", &in);
        (*roller)->y1 = in;
        fscanf(map, "%d", &in);
        (*roller)->x2 = in;
        fscanf(map, "%d", &in);
        (*roller)->y2 = in;
        roller = &(*roller)->next;
        *roller = NULL;
    }
    fclose(map);
}

void createWalls(void) {
    readFromFile();
}