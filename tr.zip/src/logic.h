#ifndef logic_h
#define logic_h

#include "struct.h"

void move_tank(char, Tank *);

double degtorad(double);

void manage_bullets(Bullet **);

void kill_old_bullets(Bullet **);

void move_bullets(Bullet *);

double radtodeg(double);

int checkWhatIsGoingOn(Tank*,Bullet*);

void addScore(Tank *tanks);

int checkScoreLimit(Tank *tanks,int scorelimit);

int killWithBullet(Tank *tanks, Bullet *bulletP);

void garbageCollector(Bullet **bullet);

void fixBirthdays(Bullet *bullet,int timeElapsed);

#endif